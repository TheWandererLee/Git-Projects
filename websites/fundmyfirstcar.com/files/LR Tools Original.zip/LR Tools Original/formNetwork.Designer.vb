<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formNetwork
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formNetwork))
        Me.btnExit = New System.Windows.Forms.Button
        Me.btnDownload = New System.Windows.Forms.Button
        Me.btnPublish = New System.Windows.Forms.Button
        Me.webUpload = New System.Windows.Forms.WebBrowser
        Me.btnBack = New System.Windows.Forms.Button
        Me.listTracks = New System.Windows.Forms.ListBox
        Me.txtName = New System.Windows.Forms.TextBox
        Me.lblName = New System.Windows.Forms.Label
        Me.webNetwork = New System.Windows.Forms.WebBrowser
        Me.lblDescription = New System.Windows.Forms.Label
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.grpPublish = New System.Windows.Forms.GroupBox
        Me.btnPublishNow = New System.Windows.Forms.Button
        Me.saveFileNetwork = New System.Windows.Forms.SaveFileDialog
        Me.btnRefresh = New System.Windows.Forms.Button
        Me.grpPublish.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(550, 421)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(150, 23)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "Exit Line Rider Network"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnDownload
        '
        Me.btnDownload.Location = New System.Drawing.Point(118, 421)
        Me.btnDownload.Name = "btnDownload"
        Me.btnDownload.Size = New System.Drawing.Size(150, 23)
        Me.btnDownload.TabIndex = 2
        Me.btnDownload.Text = "Get Track"
        Me.btnDownload.UseVisualStyleBackColor = True
        Me.btnDownload.Visible = False
        '
        'btnPublish
        '
        Me.btnPublish.Location = New System.Drawing.Point(12, 421)
        Me.btnPublish.Name = "btnPublish"
        Me.btnPublish.Size = New System.Drawing.Size(100, 23)
        Me.btnPublish.TabIndex = 3
        Me.btnPublish.Text = "Publish Track"
        Me.btnPublish.UseVisualStyleBackColor = True
        Me.btnPublish.Visible = False
        '
        'webUpload
        '
        Me.webUpload.Location = New System.Drawing.Point(481, 421)
        Me.webUpload.MinimumSize = New System.Drawing.Size(20, 20)
        Me.webUpload.Name = "webUpload"
        Me.webUpload.Size = New System.Drawing.Size(32, 32)
        Me.webUpload.TabIndex = 4
        Me.webUpload.Visible = False
        '
        'btnBack
        '
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnBack.Location = New System.Drawing.Point(-5, -1)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(72, 19)
        Me.btnBack.TabIndex = 5
        Me.btnBack.Text = "Main Page "
        Me.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'listTracks
        '
        Me.listTracks.FormattingEnabled = True
        Me.listTracks.Location = New System.Drawing.Point(6, 19)
        Me.listTracks.Name = "listTracks"
        Me.listTracks.Size = New System.Drawing.Size(400, 108)
        Me.listTracks.TabIndex = 6
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(47, 133)
        Me.txtName.MaxLength = 50
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(359, 20)
        Me.txtName.TabIndex = 7
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.SystemColors.Control
        Me.lblName.Location = New System.Drawing.Point(3, 136)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 8
        Me.lblName.Text = "Name:"
        '
        'webNetwork
        '
        Me.webNetwork.AllowWebBrowserDrop = False
        Me.webNetwork.IsWebBrowserContextMenuEnabled = False
        Me.webNetwork.Location = New System.Drawing.Point(-2, 17)
        Me.webNetwork.MinimumSize = New System.Drawing.Size(20, 20)
        Me.webNetwork.Name = "webNetwork"
        Me.webNetwork.ScriptErrorsSuppressed = True
        Me.webNetwork.Size = New System.Drawing.Size(716, 394)
        Me.webNetwork.TabIndex = 0
        Me.webNetwork.Url = New System.Uri("", System.UriKind.Relative)
        Me.webNetwork.WebBrowserShortcutsEnabled = False
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.BackColor = System.Drawing.SystemColors.Control
        Me.lblDescription.Location = New System.Drawing.Point(3, 162)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(63, 13)
        Me.lblDescription.TabIndex = 10
        Me.lblDescription.Text = "Description:"
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(72, 159)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(334, 20)
        Me.txtDescription.TabIndex = 9
        '
        'grpPublish
        '
        Me.grpPublish.Controls.Add(Me.btnPublishNow)
        Me.grpPublish.Controls.Add(Me.listTracks)
        Me.grpPublish.Controls.Add(Me.lblDescription)
        Me.grpPublish.Controls.Add(Me.txtName)
        Me.grpPublish.Controls.Add(Me.txtDescription)
        Me.grpPublish.Controls.Add(Me.lblName)
        Me.grpPublish.Location = New System.Drawing.Point(154, 100)
        Me.grpPublish.Name = "grpPublish"
        Me.grpPublish.Size = New System.Drawing.Size(412, 214)
        Me.grpPublish.TabIndex = 11
        Me.grpPublish.TabStop = False
        Me.grpPublish.Text = "Publish Track(s)"
        Me.grpPublish.Visible = False
        '
        'btnPublishNow
        '
        Me.btnPublishNow.Location = New System.Drawing.Point(156, 185)
        Me.btnPublishNow.Name = "btnPublishNow"
        Me.btnPublishNow.Size = New System.Drawing.Size(100, 23)
        Me.btnPublishNow.TabIndex = 11
        Me.btnPublishNow.Text = "Publish Now!"
        Me.btnPublishNow.UseVisualStyleBackColor = True
        '
        'saveFileNetwork
        '
        Me.saveFileNetwork.Filter = "Line Rider File (*.sol)|*.sol|All Files (*.*)|*.*"
        Me.saveFileNetwork.Title = "Type a filename to save this file as"
        '
        'btnRefresh
        '
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnRefresh.Location = New System.Drawing.Point(66, -1)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(64, 19)
        Me.btnRefresh.TabIndex = 12
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'formNetwork
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(712, 456)
        Me.Controls.Add(Me.grpPublish)
        Me.Controls.Add(Me.webUpload)
        Me.Controls.Add(Me.btnPublish)
        Me.Controls.Add(Me.btnDownload)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.webNetwork)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnRefresh)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "formNetwork"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Line Rider Network"
        Me.grpPublish.ResumeLayout(False)
        Me.grpPublish.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnDownload As System.Windows.Forms.Button
    Friend WithEvents btnPublish As System.Windows.Forms.Button
    Friend WithEvents webUpload As System.Windows.Forms.WebBrowser
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents listTracks As System.Windows.Forms.ListBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents webNetwork As System.Windows.Forms.WebBrowser
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents grpPublish As System.Windows.Forms.GroupBox
    Friend WithEvents btnPublishNow As System.Windows.Forms.Button
    Friend WithEvents saveFileNetwork As System.Windows.Forms.SaveFileDialog
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
End Class
