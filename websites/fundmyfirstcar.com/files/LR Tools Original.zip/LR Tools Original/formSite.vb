Public Class formSite
    Public returnSite As String = ""

    Private Sub formSite_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        listSite.Items.Clear()
        For Each site As String In My.Computer.FileSystem.GetDirectories(formMain.siteList)
            listSite.Items.Add(Mid(site, site.LastIndexOf("\") + 2))
        Next
    End Sub
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        returnSite = listSite.SelectedItem
        If (returnSite) = "" Then returnSite = "ic3.deviantart.com\fs12\f\2006\292\a\1"
    End Sub

    Private Sub btnLineRiderOrg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLineRiderOrg.Click
        returnSite = "www.open-tibia.com"
    End Sub

    Private Sub btnDeviantArt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeviantArt.Click
        returnSite = "ic3.deviantart.com\fs12\f\2006\292\a\1"
    End Sub
End Class