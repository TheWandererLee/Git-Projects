<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formMain))
        Me.menuMain = New System.Windows.Forms.MenuStrip
        Me.menuBtnFile = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnOpen = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnSave = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnSaveAs = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnChangeSite = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnAbout = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnExit = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnEdit = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnAddTrack = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnRenameTrack = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnRemoveTrack = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnView = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnResetTrack = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnNetwork = New System.Windows.Forms.ToolStripMenuItem
        Me.openFileMain = New System.Windows.Forms.OpenFileDialog
        Me.listVars = New System.Windows.Forms.ListBox
        Me.conMenuMain = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.menuBtnZoomIn = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnZoomOut = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnResetZoom = New System.Windows.Forms.ToolStripMenuItem
        Me.lblLine = New System.Windows.Forms.Label
        Me.comboLine = New System.Windows.Forms.ComboBox
        Me.lblTrack = New System.Windows.Forms.Label
        Me.comboTrack = New System.Windows.Forms.ComboBox
        Me.statusMain = New System.Windows.Forms.StatusStrip
        Me.statusLblOffset = New System.Windows.Forms.ToolStripStatusLabel
        Me.statusLblZoom = New System.Windows.Forms.ToolStripStatusLabel
        Me.statusLblLineLength = New System.Windows.Forms.ToolStripStatusLabel
        Me.statusLblLineSlope = New System.Windows.Forms.ToolStripStatusLabel
        Me.statusLblPosition = New System.Windows.Forms.ToolStripStatusLabel
        Me.pnlMain = New System.Windows.Forms.Panel
        Me.radDrawBeziers = New System.Windows.Forms.RadioButton
        Me.radDrawLines = New System.Windows.Forms.RadioButton
        Me.pnlTrack = New System.Windows.Forms.Panel
        Me.saveFileMain = New System.Windows.Forms.SaveFileDialog
        Me.conMenuSelect = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.menuBtnSetStart = New System.Windows.Forms.ToolStripMenuItem
        Me.conMenuSelectSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.menuBtnSZoomIn = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnSZoomOut = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnSResetZoom = New System.Windows.Forms.ToolStripMenuItem
        Me.timDrawTrack = New System.Windows.Forms.Timer(Me.components)
        Me.folderMain = New System.Windows.Forms.FolderBrowserDialog
        Me.radTrackSelect = New System.Windows.Forms.RadioButton
        Me.radTrackErase = New System.Windows.Forms.RadioButton
        Me.radTrackDraw = New System.Windows.Forms.RadioButton
        Me.radTrackMove = New System.Windows.Forms.RadioButton
        Me.picMain = New System.Windows.Forms.PictureBox
        Me.cboxAntiAlias = New System.Windows.Forms.CheckBox
        Me.lblY2 = New System.Windows.Forms.Label
        Me.lblX1 = New System.Windows.Forms.Label
        Me.txtY2 = New System.Windows.Forms.TextBox
        Me.lblY1 = New System.Windows.Forms.Label
        Me.txtY1 = New System.Windows.Forms.TextBox
        Me.txtX1 = New System.Windows.Forms.TextBox
        Me.txtX2 = New System.Windows.Forms.TextBox
        Me.lblX2 = New System.Windows.Forms.Label
        Me.menuMain.SuspendLayout()
        Me.conMenuMain.SuspendLayout()
        Me.statusMain.SuspendLayout()
        Me.pnlMain.SuspendLayout()
        Me.pnlTrack.SuspendLayout()
        Me.conMenuSelect.SuspendLayout()
        CType(Me.picMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'menuMain
        '
        Me.menuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnFile, Me.menuBtnEdit, Me.menuBtnView, Me.menuBtnNetwork})
        Me.menuMain.Location = New System.Drawing.Point(0, 0)
        Me.menuMain.Name = "menuMain"
        Me.menuMain.Size = New System.Drawing.Size(712, 24)
        Me.menuMain.TabIndex = 0
        Me.menuMain.Text = "Main Menu"
        '
        'menuBtnFile
        '
        Me.menuBtnFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnOpen, Me.menuBtnSave, Me.menuBtnSaveAs, Me.menuBtnChangeSite, Me.menuBtnAbout, Me.menuBtnExit})
        Me.menuBtnFile.Name = "menuBtnFile"
        Me.menuBtnFile.Size = New System.Drawing.Size(35, 20)
        Me.menuBtnFile.Text = "File"
        '
        'menuBtnOpen
        '
        Me.menuBtnOpen.Name = "menuBtnOpen"
        Me.menuBtnOpen.Size = New System.Drawing.Size(176, 22)
        Me.menuBtnOpen.Text = "Open..."
        '
        'menuBtnSave
        '
        Me.menuBtnSave.Name = "menuBtnSave"
        Me.menuBtnSave.Size = New System.Drawing.Size(176, 22)
        Me.menuBtnSave.Text = "Save"
        '
        'menuBtnSaveAs
        '
        Me.menuBtnSaveAs.Name = "menuBtnSaveAs"
        Me.menuBtnSaveAs.Size = New System.Drawing.Size(176, 22)
        Me.menuBtnSaveAs.Text = "Save As..."
        '
        'menuBtnChangeSite
        '
        Me.menuBtnChangeSite.Name = "menuBtnChangeSite"
        Me.menuBtnChangeSite.Size = New System.Drawing.Size(176, 22)
        Me.menuBtnChangeSite.Text = "Change Website..."
        '
        'menuBtnAbout
        '
        Me.menuBtnAbout.Name = "menuBtnAbout"
        Me.menuBtnAbout.Size = New System.Drawing.Size(176, 22)
        Me.menuBtnAbout.Text = "About"
        '
        'menuBtnExit
        '
        Me.menuBtnExit.Name = "menuBtnExit"
        Me.menuBtnExit.Size = New System.Drawing.Size(176, 22)
        Me.menuBtnExit.Text = "Exit"
        '
        'menuBtnEdit
        '
        Me.menuBtnEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnAddTrack, Me.menuBtnRenameTrack, Me.menuBtnRemoveTrack})
        Me.menuBtnEdit.Name = "menuBtnEdit"
        Me.menuBtnEdit.Size = New System.Drawing.Size(37, 20)
        Me.menuBtnEdit.Text = "Edit"
        '
        'menuBtnAddTrack
        '
        Me.menuBtnAddTrack.Name = "menuBtnAddTrack"
        Me.menuBtnAddTrack.Size = New System.Drawing.Size(153, 22)
        Me.menuBtnAddTrack.Text = "Add Track"
        '
        'menuBtnRenameTrack
        '
        Me.menuBtnRenameTrack.Name = "menuBtnRenameTrack"
        Me.menuBtnRenameTrack.Size = New System.Drawing.Size(153, 22)
        Me.menuBtnRenameTrack.Text = "Rename Track"
        '
        'menuBtnRemoveTrack
        '
        Me.menuBtnRemoveTrack.Name = "menuBtnRemoveTrack"
        Me.menuBtnRemoveTrack.Size = New System.Drawing.Size(153, 22)
        Me.menuBtnRemoveTrack.Text = "Remove Track"
        '
        'menuBtnView
        '
        Me.menuBtnView.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnResetTrack})
        Me.menuBtnView.Name = "menuBtnView"
        Me.menuBtnView.Size = New System.Drawing.Size(41, 20)
        Me.menuBtnView.Text = "View"
        '
        'menuBtnResetTrack
        '
        Me.menuBtnResetTrack.Name = "menuBtnResetTrack"
        Me.menuBtnResetTrack.Size = New System.Drawing.Size(180, 22)
        Me.menuBtnResetTrack.Text = "Reset Track Render"
        '
        'menuBtnNetwork
        '
        Me.menuBtnNetwork.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.menuBtnNetwork.Name = "menuBtnNetwork"
        Me.menuBtnNetwork.Size = New System.Drawing.Size(109, 20)
        Me.menuBtnNetwork.Text = "Line Rider Network"
        '
        'openFileMain
        '
        Me.openFileMain.Filter = "Line Rider File (*.sol)|*.sol|All Files (*.*)|*.*"
        Me.openFileMain.Title = "Open Line Rider File"
        '
        'listVars
        '
        Me.listVars.FormattingEnabled = True
        Me.listVars.Items.AddRange(New Object() {"Debug List"})
        Me.listVars.Location = New System.Drawing.Point(568, 51)
        Me.listVars.Name = "listVars"
        Me.listVars.Size = New System.Drawing.Size(143, 17)
        Me.listVars.TabIndex = 5
        Me.listVars.Visible = False
        '
        'conMenuMain
        '
        Me.conMenuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnZoomIn, Me.menuBtnZoomOut, Me.menuBtnResetZoom})
        Me.conMenuMain.Name = "conMenuTrack"
        Me.conMenuMain.Size = New System.Drawing.Size(143, 70)
        '
        'menuBtnZoomIn
        '
        Me.menuBtnZoomIn.Name = "menuBtnZoomIn"
        Me.menuBtnZoomIn.Size = New System.Drawing.Size(142, 22)
        Me.menuBtnZoomIn.Text = "Zoom In"
        '
        'menuBtnZoomOut
        '
        Me.menuBtnZoomOut.Name = "menuBtnZoomOut"
        Me.menuBtnZoomOut.Size = New System.Drawing.Size(142, 22)
        Me.menuBtnZoomOut.Text = "Zoom Out"
        '
        'menuBtnResetZoom
        '
        Me.menuBtnResetZoom.Name = "menuBtnResetZoom"
        Me.menuBtnResetZoom.Size = New System.Drawing.Size(142, 22)
        Me.menuBtnResetZoom.Text = "Reset Zoom"
        '
        'lblLine
        '
        Me.lblLine.AutoSize = True
        Me.lblLine.Location = New System.Drawing.Point(11, 33)
        Me.lblLine.Name = "lblLine"
        Me.lblLine.Size = New System.Drawing.Size(30, 13)
        Me.lblLine.TabIndex = 7
        Me.lblLine.Text = "Line:"
        '
        'comboLine
        '
        Me.comboLine.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboLine.FormattingEnabled = True
        Me.comboLine.Location = New System.Drawing.Point(44, 30)
        Me.comboLine.Name = "comboLine"
        Me.comboLine.Size = New System.Drawing.Size(96, 21)
        Me.comboLine.TabIndex = 8
        '
        'lblTrack
        '
        Me.lblTrack.AutoSize = True
        Me.lblTrack.Location = New System.Drawing.Point(3, 6)
        Me.lblTrack.Name = "lblTrack"
        Me.lblTrack.Size = New System.Drawing.Size(38, 13)
        Me.lblTrack.TabIndex = 9
        Me.lblTrack.Text = "Track:"
        '
        'comboTrack
        '
        Me.comboTrack.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboTrack.FormattingEnabled = True
        Me.comboTrack.Location = New System.Drawing.Point(44, 3)
        Me.comboTrack.Name = "comboTrack"
        Me.comboTrack.Size = New System.Drawing.Size(192, 21)
        Me.comboTrack.TabIndex = 10
        '
        'statusMain
        '
        Me.statusMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statusLblOffset, Me.statusLblZoom, Me.statusLblLineLength, Me.statusLblLineSlope, Me.statusLblPosition})
        Me.statusMain.Location = New System.Drawing.Point(0, 434)
        Me.statusMain.Name = "statusMain"
        Me.statusMain.Size = New System.Drawing.Size(712, 22)
        Me.statusMain.TabIndex = 21
        Me.statusMain.Text = "Main Status Bar"
        '
        'statusLblOffset
        '
        Me.statusLblOffset.Name = "statusLblOffset"
        Me.statusLblOffset.Size = New System.Drawing.Size(42, 17)
        Me.statusLblOffset.Text = "Offset:"
        '
        'statusLblZoom
        '
        Me.statusLblZoom.Name = "statusLblZoom"
        Me.statusLblZoom.Size = New System.Drawing.Size(37, 17)
        Me.statusLblZoom.Text = "Zoom:"
        '
        'statusLblLineLength
        '
        Me.statusLblLineLength.Name = "statusLblLineLength"
        Me.statusLblLineLength.Size = New System.Drawing.Size(66, 17)
        Me.statusLblLineLength.Text = "Line Length:"
        '
        'statusLblLineSlope
        '
        Me.statusLblLineSlope.Name = "statusLblLineSlope"
        Me.statusLblLineSlope.Size = New System.Drawing.Size(59, 17)
        Me.statusLblLineSlope.Text = "Line Slope:"
        '
        'statusLblPosition
        '
        Me.statusLblPosition.Name = "statusLblPosition"
        Me.statusLblPosition.Size = New System.Drawing.Size(82, 17)
        Me.statusLblPosition.Text = "Mouse Position:"
        '
        'pnlMain
        '
        Me.pnlMain.Controls.Add(Me.lblY2)
        Me.pnlMain.Controls.Add(Me.lblX1)
        Me.pnlMain.Controls.Add(Me.txtY2)
        Me.pnlMain.Controls.Add(Me.lblY1)
        Me.pnlMain.Controls.Add(Me.txtY1)
        Me.pnlMain.Controls.Add(Me.txtX1)
        Me.pnlMain.Controls.Add(Me.txtX2)
        Me.pnlMain.Controls.Add(Me.lblX2)
        Me.pnlMain.Controls.Add(Me.cboxAntiAlias)
        Me.pnlMain.Controls.Add(Me.radDrawBeziers)
        Me.pnlMain.Controls.Add(Me.radDrawLines)
        Me.pnlMain.Controls.Add(Me.pnlTrack)
        Me.pnlMain.Controls.Add(Me.lblTrack)
        Me.pnlMain.Controls.Add(Me.lblLine)
        Me.pnlMain.Controls.Add(Me.listVars)
        Me.pnlMain.Controls.Add(Me.comboLine)
        Me.pnlMain.Controls.Add(Me.comboTrack)
        Me.pnlMain.Location = New System.Drawing.Point(0, 370)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(712, 64)
        Me.pnlMain.TabIndex = 23
        '
        'radDrawBeziers
        '
        Me.radDrawBeziers.AutoSize = True
        Me.radDrawBeziers.Location = New System.Drawing.Point(377, 31)
        Me.radDrawBeziers.Name = "radDrawBeziers"
        Me.radDrawBeziers.Size = New System.Drawing.Size(58, 17)
        Me.radDrawBeziers.TabIndex = 27
        Me.radDrawBeziers.Text = "Curves"
        Me.radDrawBeziers.UseVisualStyleBackColor = True
        '
        'radDrawLines
        '
        Me.radDrawLines.AutoSize = True
        Me.radDrawLines.Checked = True
        Me.radDrawLines.Location = New System.Drawing.Point(377, 4)
        Me.radDrawLines.Name = "radDrawLines"
        Me.radDrawLines.Size = New System.Drawing.Size(50, 17)
        Me.radDrawLines.TabIndex = 26
        Me.radDrawLines.TabStop = True
        Me.radDrawLines.Text = "Lines"
        Me.radDrawLines.UseVisualStyleBackColor = True
        '
        'pnlTrack
        '
        Me.pnlTrack.BackColor = System.Drawing.Color.White
        Me.pnlTrack.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlTrack.Controls.Add(Me.radTrackSelect)
        Me.pnlTrack.Controls.Add(Me.radTrackErase)
        Me.pnlTrack.Controls.Add(Me.radTrackDraw)
        Me.pnlTrack.Controls.Add(Me.radTrackMove)
        Me.pnlTrack.Enabled = False
        Me.pnlTrack.Location = New System.Drawing.Point(242, 3)
        Me.pnlTrack.Name = "pnlTrack"
        Me.pnlTrack.Size = New System.Drawing.Size(129, 48)
        Me.pnlTrack.TabIndex = 25
        '
        'saveFileMain
        '
        Me.saveFileMain.Filter = "Line Rider File (*.sol)|*.sol|All Files (*.*)|*.*"
        Me.saveFileMain.Title = "Save Line Rider File"
        '
        'conMenuSelect
        '
        Me.conMenuSelect.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnSetStart, Me.conMenuSelectSeparator1, Me.menuBtnSZoomIn, Me.menuBtnSZoomOut, Me.menuBtnSResetZoom})
        Me.conMenuSelect.Name = "conMenuTrack"
        Me.conMenuSelect.Size = New System.Drawing.Size(175, 98)
        '
        'menuBtnSetStart
        '
        Me.menuBtnSetStart.Enabled = False
        Me.menuBtnSetStart.Name = "menuBtnSetStart"
        Me.menuBtnSetStart.Size = New System.Drawing.Size(174, 22)
        Me.menuBtnSetStart.Text = "Set as starting line"
        '
        'conMenuSelectSeparator1
        '
        Me.conMenuSelectSeparator1.Name = "conMenuSelectSeparator1"
        Me.conMenuSelectSeparator1.Size = New System.Drawing.Size(171, 6)
        '
        'menuBtnSZoomIn
        '
        Me.menuBtnSZoomIn.Name = "menuBtnSZoomIn"
        Me.menuBtnSZoomIn.Size = New System.Drawing.Size(174, 22)
        Me.menuBtnSZoomIn.Text = "Zoom In"
        '
        'menuBtnSZoomOut
        '
        Me.menuBtnSZoomOut.Name = "menuBtnSZoomOut"
        Me.menuBtnSZoomOut.Size = New System.Drawing.Size(174, 22)
        Me.menuBtnSZoomOut.Text = "Zoom Out"
        '
        'menuBtnSResetZoom
        '
        Me.menuBtnSResetZoom.Name = "menuBtnSResetZoom"
        Me.menuBtnSResetZoom.Size = New System.Drawing.Size(174, 22)
        Me.menuBtnSResetZoom.Text = "Reset Zoom"
        '
        'timDrawTrack
        '
        '
        'folderMain
        '
        Me.folderMain.Description = "Please select the website that you play line rider from."
        Me.folderMain.RootFolder = System.Environment.SpecialFolder.ApplicationData
        Me.folderMain.ShowNewFolderButton = False
        '
        'radTrackSelect
        '
        Me.radTrackSelect.BackColor = System.Drawing.Color.White
        Me.radTrackSelect.CheckAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackSelect.Cursor = System.Windows.Forms.Cursors.Hand
        Me.radTrackSelect.Image = Global.LR_Tools.My.Resources.Resources.lrmouse
        Me.radTrackSelect.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackSelect.Location = New System.Drawing.Point(92, -2)
        Me.radTrackSelect.Name = "radTrackSelect"
        Me.radTrackSelect.Size = New System.Drawing.Size(31, 46)
        Me.radTrackSelect.TabIndex = 27
        Me.radTrackSelect.UseVisualStyleBackColor = False
        '
        'radTrackErase
        '
        Me.radTrackErase.BackColor = System.Drawing.Color.White
        Me.radTrackErase.CheckAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackErase.Cursor = System.Windows.Forms.Cursors.Hand
        Me.radTrackErase.Image = CType(resources.GetObject("radTrackErase.Image"), System.Drawing.Image)
        Me.radTrackErase.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackErase.Location = New System.Drawing.Point(62, -2)
        Me.radTrackErase.Name = "radTrackErase"
        Me.radTrackErase.Size = New System.Drawing.Size(31, 46)
        Me.radTrackErase.TabIndex = 26
        Me.radTrackErase.UseVisualStyleBackColor = False
        '
        'radTrackDraw
        '
        Me.radTrackDraw.BackColor = System.Drawing.Color.White
        Me.radTrackDraw.CheckAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackDraw.Cursor = System.Windows.Forms.Cursors.Hand
        Me.radTrackDraw.Image = Global.LR_Tools.My.Resources.Resources.lrpencil
        Me.radTrackDraw.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackDraw.Location = New System.Drawing.Point(32, -2)
        Me.radTrackDraw.Name = "radTrackDraw"
        Me.radTrackDraw.Size = New System.Drawing.Size(31, 46)
        Me.radTrackDraw.TabIndex = 25
        Me.radTrackDraw.UseVisualStyleBackColor = False
        '
        'radTrackMove
        '
        Me.radTrackMove.BackColor = System.Drawing.Color.White
        Me.radTrackMove.CheckAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackMove.Checked = True
        Me.radTrackMove.Cursor = System.Windows.Forms.Cursors.Hand
        Me.radTrackMove.Image = Global.LR_Tools.My.Resources.Resources.lrhand
        Me.radTrackMove.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radTrackMove.Location = New System.Drawing.Point(2, -2)
        Me.radTrackMove.Name = "radTrackMove"
        Me.radTrackMove.Size = New System.Drawing.Size(31, 46)
        Me.radTrackMove.TabIndex = 24
        Me.radTrackMove.TabStop = True
        Me.radTrackMove.UseVisualStyleBackColor = False
        '
        'picMain
        '
        Me.picMain.BackColor = System.Drawing.Color.White
        Me.picMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picMain.ContextMenuStrip = Me.conMenuMain
        Me.picMain.Cursor = System.Windows.Forms.Cursors.SizeAll
        Me.picMain.Location = New System.Drawing.Point(0, 24)
        Me.picMain.Name = "picMain"
        Me.picMain.Size = New System.Drawing.Size(712, 340)
        Me.picMain.TabIndex = 6
        Me.picMain.TabStop = False
        '
        'cboxAntiAlias
        '
        Me.cboxAntiAlias.AutoSize = True
        Me.cboxAntiAlias.Location = New System.Drawing.Point(146, 32)
        Me.cboxAntiAlias.Name = "cboxAntiAlias"
        Me.cboxAntiAlias.Size = New System.Drawing.Size(83, 17)
        Me.cboxAntiAlias.TabIndex = 28
        Me.cboxAntiAlias.Text = "High-Quality"
        Me.cboxAntiAlias.UseVisualStyleBackColor = True
        '
        'lblY2
        '
        Me.lblY2.AutoSize = True
        Me.lblY2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblY2.Location = New System.Drawing.Point(652, 29)
        Me.lblY2.Name = "lblY2"
        Me.lblY2.Size = New System.Drawing.Size(18, 12)
        Me.lblY2.TabIndex = 36
        Me.lblY2.Text = "Y2:"
        '
        'lblX1
        '
        Me.lblX1.AutoSize = True
        Me.lblX1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblX1.Location = New System.Drawing.Point(585, 3)
        Me.lblX1.Name = "lblX1"
        Me.lblX1.Size = New System.Drawing.Size(19, 12)
        Me.lblX1.TabIndex = 30
        Me.lblX1.Text = "X1:"
        '
        'txtY2
        '
        Me.txtY2.Enabled = False
        Me.txtY2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtY2.Location = New System.Drawing.Point(670, 26)
        Me.txtY2.Name = "txtY2"
        Me.txtY2.Size = New System.Drawing.Size(42, 18)
        Me.txtY2.TabIndex = 35
        Me.txtY2.Text = "0"
        '
        'lblY1
        '
        Me.lblY1.AutoSize = True
        Me.lblY1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblY1.Location = New System.Drawing.Point(652, 3)
        Me.lblY1.Name = "lblY1"
        Me.lblY1.Size = New System.Drawing.Size(18, 12)
        Me.lblY1.TabIndex = 32
        Me.lblY1.Text = "Y1:"
        '
        'txtY1
        '
        Me.txtY1.Enabled = False
        Me.txtY1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtY1.Location = New System.Drawing.Point(670, 0)
        Me.txtY1.Name = "txtY1"
        Me.txtY1.Size = New System.Drawing.Size(42, 18)
        Me.txtY1.TabIndex = 31
        Me.txtY1.Text = "0"
        '
        'txtX1
        '
        Me.txtX1.Enabled = False
        Me.txtX1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtX1.Location = New System.Drawing.Point(604, 0)
        Me.txtX1.Name = "txtX1"
        Me.txtX1.Size = New System.Drawing.Size(42, 18)
        Me.txtX1.TabIndex = 29
        Me.txtX1.Text = "1123456"
        '
        'txtX2
        '
        Me.txtX2.Enabled = False
        Me.txtX2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtX2.Location = New System.Drawing.Point(604, 26)
        Me.txtX2.Name = "txtX2"
        Me.txtX2.Size = New System.Drawing.Size(42, 18)
        Me.txtX2.TabIndex = 33
        Me.txtX2.Text = "0"
        '
        'lblX2
        '
        Me.lblX2.AutoSize = True
        Me.lblX2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblX2.Location = New System.Drawing.Point(585, 29)
        Me.lblX2.Name = "lblX2"
        Me.lblX2.Size = New System.Drawing.Size(19, 12)
        Me.lblX2.TabIndex = 34
        Me.lblX2.Text = "X2:"
        '
        'formMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(712, 456)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.statusMain)
        Me.Controls.Add(Me.menuMain)
        Me.Controls.Add(Me.picMain)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.menuMain
        Me.Name = "formMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LR Tools"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.menuMain.ResumeLayout(False)
        Me.menuMain.PerformLayout()
        Me.conMenuMain.ResumeLayout(False)
        Me.statusMain.ResumeLayout(False)
        Me.statusMain.PerformLayout()
        Me.pnlMain.ResumeLayout(False)
        Me.pnlMain.PerformLayout()
        Me.pnlTrack.ResumeLayout(False)
        Me.conMenuSelect.ResumeLayout(False)
        CType(Me.picMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents menuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents openFileMain As System.Windows.Forms.OpenFileDialog
    Friend WithEvents listVars As System.Windows.Forms.ListBox
    Friend WithEvents picMain As System.Windows.Forms.PictureBox
    Friend WithEvents lblLine As System.Windows.Forms.Label
    Friend WithEvents comboLine As System.Windows.Forms.ComboBox
    Friend WithEvents lblTrack As System.Windows.Forms.Label
    Friend WithEvents comboTrack As System.Windows.Forms.ComboBox
    Friend WithEvents statusMain As System.Windows.Forms.StatusStrip
    Friend WithEvents conMenuMain As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents menuBtnZoomIn As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnZoomOut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents statusLblOffset As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents statusLblZoom As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents statusLblPosition As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents radTrackMove As System.Windows.Forms.RadioButton
    Friend WithEvents pnlTrack As System.Windows.Forms.Panel
    Friend WithEvents statusLblLineSlope As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents radTrackDraw As System.Windows.Forms.RadioButton
    Friend WithEvents statusLblLineLength As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents menuBtnFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnView As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnResetTrack As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnSaveAs As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents saveFileMain As System.Windows.Forms.SaveFileDialog
    Friend WithEvents radTrackErase As System.Windows.Forms.RadioButton
    Friend WithEvents radTrackSelect As System.Windows.Forms.RadioButton
    Friend WithEvents conMenuSelect As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents menuBtnSetStart As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents conMenuSelectSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents menuBtnSZoomIn As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnSZoomOut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents timDrawTrack As System.Windows.Forms.Timer
    Friend WithEvents radDrawBeziers As System.Windows.Forms.RadioButton
    Friend WithEvents radDrawLines As System.Windows.Forms.RadioButton
    Friend WithEvents menuBtnNetwork As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents folderMain As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents menuBtnChangeSite As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnResetZoom As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnSResetZoom As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnRenameTrack As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnAddTrack As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnRemoveTrack As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cboxAntiAlias As System.Windows.Forms.CheckBox
    Friend WithEvents lblY2 As System.Windows.Forms.Label
    Friend WithEvents lblX1 As System.Windows.Forms.Label
    Friend WithEvents txtY2 As System.Windows.Forms.TextBox
    Friend WithEvents lblY1 As System.Windows.Forms.Label
    Friend WithEvents txtY1 As System.Windows.Forms.TextBox
    Friend WithEvents txtX1 As System.Windows.Forms.TextBox
    Friend WithEvents txtX2 As System.Windows.Forms.TextBox
    Friend WithEvents lblX2 As System.Windows.Forms.Label

End Class
