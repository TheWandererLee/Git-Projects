Public Class formInput
    Private Sub formInput_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Default select the input textbox
        txtInput.Select()
    End Sub
End Class