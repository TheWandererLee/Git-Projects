Public Class formMain

#Region "    Global Variables"
    Dim vbQuote As String = Chr(34)

    Dim programFiles As String = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)
    Dim company As String = My.Application.Info.CompanyName
    Dim program As String = My.Application.Info.Title
    Dim settings As String = "settings.dat"
    Dim settingsFile As String = programFiles & "\" & company & "\" & program & "\" & settings
    Public lrSite As String = ""
    Public siteList As String = ""
    Public trackPath As String = ""

    Dim arrayInset As Integer = 0
    Dim arrayTabspace As Integer = 2
    Dim arrayName(100) As String
    Dim arrayType(100) As String

    Public tracks(1000) As String 'Name of this track
    Dim tracksep(1000) As Double 'Track separating positions
    Dim line(100000) As Integer 'Track ID that this line is a part of
    Dim x1(100000) As Double 'X-Coord of first point of line
    Dim y1(100000) As Double 'Y-Coord of first point of line
    Dim x2(100000) As Double 'X-Coord of second point of line
    Dim y2(100000) As Double 'Y-Coord of second point of line
    Dim linesa(100000) As Point
    Dim linesb(100000) As Point

    Dim idoffset(100000) As Integer 'Offset of an object in the file

    Dim currentItem(1000) As Double

    Dim lineCount As Double = 0
    Dim smoothSteps As Integer = 10
    Dim dontCenterPoint As Boolean = False
    Dim ignoreLineChange As Boolean = False
    Dim drawSelectedLine As Boolean = True
    Dim draw3D As Boolean = False
    Dim minline As Integer = 12 'Minimum length that a line can be, relative to zoom size
    Dim selectSensitivity As Integer = 8 'Distance from a select point on a line to the mouse that will return true (selected)
    Dim selectChecks As Integer = 20 'Number of points along a line that should be checked near mouse
    Dim eraseSensitivity As Integer = 8 'Distance from an erase point on a line to the mouse that will return true (intersecting)
    Dim eraseChecks As Integer = 20 'Number of points along a line that should be checked near eraser
    Dim predictLength As Integer = 100
    Dim changeTo As Integer = -1

    Dim lastx As Double = 0
    Dim lasty As Double = 0
    Dim lastxx As Double = 0
    Dim lastyy As Double = 0
    Dim lastxxx As Double = 0
    Dim lastyyy As Double = 0
    Dim drawNext As Boolean = True
    Dim lastmp As Point = New Point(0, 0)
    Dim origoffsetx As Double = 0
    Dim origoffsety As Double = 0
    Dim offsetx As Double = 0
    Dim offsety As Double = 0
    Dim offx1 As Double, offy1 As Double, offx2 As Double, offy2 As Double
    Dim zoomx As Double = 1
    Dim zoomy As Double = 1
    Dim onLine As Double = -1
    Dim onLines(100000) As Double
    Dim lineArea As Rectangle = New Rectangle(0, 0, 0, 0)

    Dim pressedOnPic As Boolean = False
    Dim trackName As String = ""
    Dim trackHeader(15) As Byte

    Dim trackGraphics As Graphics
    Dim trackMoveStart As Point = New Point(0, 0)
#End Region
#Region "    Byte Converting References"
    Private Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" _
        (ByRef d As Double, ByRef s As Byte, ByVal nbytes As Integer)
    Private Declare Sub CopyMemory2 Lib "kernel32" Alias "RtlMoveMemory" _
        (ByRef s As Byte, ByRef d As Double, ByVal nbytes As Integer)
#End Region

    Private Sub formMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For i As Integer = 0 To 1000
            currentItem(i) = 0
        Next
        trackGraphics = picMain.CreateGraphics()
        'trackGraphics.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias
        Me.WindowState = FormWindowState.Normal
        Me.CenterToScreen()

        testDirectories()
        loadSettings()
    End Sub
    Private Sub formMain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        picMain.Size = New Size(Me.Width - 8, Me.Height - 150)
        pnlMain.Top = Me.Height - 120
    End Sub

    'File
    Private Sub menuBtnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnOpen.Click
        Try
            If (openFileMain.ShowDialog = Windows.Forms.DialogResult.OK) Then
                openFile(openFileMain.FileName)
            End If
        Catch
            openFileMain.FileName = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\Macromedia\"
            If (openFileMain.ShowDialog = Windows.Forms.DialogResult.OK) Then
                openFile(openFileMain.FileName)
            End If
        End Try
    End Sub
    Private Sub menuBtnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnSave.Click
        If (openFileMain.FileName <> "") Then saveFile(openFileMain.FileName)
    End Sub
    Private Sub menuBtnSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnSaveAs.Click
        saveFileMain.FileName = openFileMain.FileName
        If (saveFileMain.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            saveFile(saveFileMain.FileName)
            openFileMain.FileName = saveFileMain.FileName
        End If
    End Sub
    Private Sub menuBtnChangeSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnChangeSite.Click
        Try
            My.Computer.FileSystem.WriteAllText(settingsFile, "", False)
        Catch
            MsgBox("Couldn't change website, settings file is in use.", MsgBoxStyle.Critical, "Unable to Change Website")
        End Try
        loadSettings()
    End Sub
    Private Sub menuBtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnExit.Click
        Me.Close()
    End Sub

    'File reading and writing functions
    Private Sub openFile(ByVal fileName As String)
        For i As Integer = 0 To tracks.Length - 1
            tracks(i) = Nothing
        Next
        Dim fReader As New System.IO.FileStream(fileName, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

        For i As Integer = 0 To 15 'Save track header
            trackHeader(i) = fReader.ReadByte()
        Next

        Dim n As Integer = readLength(fReader) 'Read length of shared object name
        trackName = readString(fReader, n) 'Read shared object name

        fReader.Seek(4, IO.SeekOrigin.Current) 'Skip 4 bytes (always 00 00 00 00)

        listVars.Items.Clear() 'Clear debug list (currently unused)
        comboTrack.Items.Clear() 'Clear track selection list
        Dim seekTo As Integer = 0
        Dim inc As Double = 0
        Dim trackinc As Integer = 0
        Dim thisID As Integer = 1
        Dim currentArray As String = ""
        While (fReader.Position < fReader.Length - 1)
reread:
            idoffset(thisID) = fReader.Position() 'Store offset of current ID (for pointers)
            n = readLength(fReader) 'Read length of item

            If (n = 0) Then 'Check if an array is being closed (used for pointers)
                If (fReader.ReadByte() = 9) Then
                    'arrayInset -= 1
                    'listVars.Items.Add(inset() & "<<End " & arrayType(arrayInset) & " (" & arrayName(arrayInset) & ")")
                    'listVars.Items.Add("")
                    If (seekTo <> 0) Then
                        fReader.Seek(seekTo, IO.SeekOrigin.Begin)
                        seekTo = 0
                    ElseIf (currentArray = "trackList" And fReader.Position = 50) Then
                        If (MsgBox("This is a blank Line Rider file, would you like to start a new track set?", MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo, "Empty Line Rider File") = MsgBoxResult.Yes) Then
                            addTrack()
                        End If
                        fReader.Close()
                        Exit Sub
                    End If
                    GoTo nextElement
                Else
                    fReader.Seek(-1, IO.SeekOrigin.Current) 'Tested false, go back and continue
                End If
            End If

            Dim thisName As String = readString(fReader, n) 'Read item name
            Dim thisType As Byte = fReader.ReadByte() 'Read item type
            Dim thisValue As Double = 0
            Dim thisItems As Integer = 0
            Dim thisOffset As Long = fReader.Position()

            If (thisType = 0) Then 'Number (Double)
                thisValue = stringToDouble(readHexString(fReader, 8))
                'listVars.Items.Add(inset() & thisName & " [Number]: " & thisValue)
                If (thisName = "0") Then x1(inc) = thisValue
                If (thisName = "1") Then y1(inc) = thisValue
                If (thisName = "2") Then x2(inc) = thisValue
                If (thisName = "3") Then y2(inc) = thisValue
                If (thisName = "4") Then
                    line(inc) = trackinc
                    inc += 1
                End If
            End If
            If (thisType = 2) Then 'String
                Dim tmp As Integer = readLength(fReader)
                Dim thisString As String = readString(fReader, tmp)
                If (thisName = "label") Then
                    comboTrack.Items.Add(thisString)
                    tracks(trackinc) = thisString
                    tracksep(trackinc) = inc
                    trackinc = trackinc + 1
                End If
                'listVars.Items.Add(inset() & thisName & " [String]: " & thisString)
            End If
            If (thisType = 3) Then 'Object
                thisID += 1
                'listVars.Items.Add(inset() & ">>Begin Object (" & thisName & ")")
                'arrayName(arrayInset) = thisName
                'arrayType(arrayInset) = "Object"
                'arrayInset += 1
            End If
            If (thisType = 7) Then 'Pointer
                thisValue = readLength(fReader)
                seekTo = fReader.Position
                fReader.Seek(idoffset(thisValue), IO.SeekOrigin.Begin)
                GoTo reread
                'listVars.Items.Add(inset() & thisName & " [Pointer]: " & thisValue)
            End If
            If (thisType = 8) Then 'Array [Store array name to check if blank file]
                currentArray = thisName
                thisItems = readFour(fReader)
                thisID += 1
                'listVars.Items.Add(inset() & ">>Begin Array (" & thisName & "): " & thisItems & " Items")
                'arrayName(arrayInset) = thisName
                'arrayType(arrayInset) = "Array"
                'arrayInset += 1
            End If
nextElement:
        End While

        comboTrack.SelectedIndex = 0
        lineCount = inc - 1
        fReader.Close()

        resetOffset()
        resetZoom()

        If (pnlTrack.Enabled = False) Then pnlTrack.Enabled = True
        timDrawTrack.Enabled = True
    End Sub
    Private Sub saveFile(ByVal fileName As String)
        Dim fWriter As New System.IO.FileStream(fileName, IO.FileMode.OpenOrCreate, IO.FileAccess.Write, IO.FileShare.Read)
        fWriter.Write(hexStringToBytes("00BF"), 0, 2) 'Unknown first 2 bytes 00 BF
        fWriter.Write(hexStringToBytes("00000000"), 0, 4) 'Reserved space used for filesize later
        fWriter.Write(stringToBytes("TCSO"), 0, 4) 'Filetype TCSO
        fWriter.Write(hexStringToBytes("000400000000"), 0, 6) 'Unknown 6 bytes 00 04 00 00 00 00
        fWriter.Write(shortToBytes(9), 0, 2) 'Length of array name (undefined)
        fWriter.Write(stringToBytes("undefined"), 0, 9) 'Initialize data
        fWriter.Write(hexStringToBytes("00000000"), 0, 4) 'Unknown 4 bytes 00 00 00 00
        fWriter.Write(shortToBytes(9), 0, 2) 'Length of array name (trackList)
        fWriter.Write(stringToBytes("trackList"), 0, 9) 'Begin trackList array
        fWriter.Write(byteToBytes(8), 0, 1) 'Set trackList as type array (8)
        fWriter.Write(longToBytes(comboTrack.Items.Count), 0, 4) 'Number of tracks
        For i As Integer = 0 To comboTrack.Items.Count - 1
            Dim trackName As String = comboTrack.Items.Item(i)
            fWriter.Write(shortToBytes(CStr(i).Length), 0, 2) 'Length of track number
            fWriter.Write(stringToBytes(CStr(i)), 0, CStr(i).Length) 'Track number
            fWriter.Write(byteToBytes(3), 0, 1) 'Set track number as type object (3)
            fWriter.Write(shortToBytes(4), 0, 2) 'Length of array name (data)
            fWriter.Write(stringToBytes("data"), 0, 4) 'Begin data array (contains lines)
            fWriter.Write(byteToBytes(8), 0, 1) 'Set data as type array (8)
            Dim nol As Long = tracksep(i) - 0
            If (i > 0) Then nol = tracksep(i) - tracksep(i - 1)
            Dim lineadd As Long = 0
            If (i > 0) Then lineadd = tracksep(i - 1)
            fWriter.Write(longToBytes(nol), 0, 4) 'Number of lines in track
            nol -= 1 'Move number of lines down one because array starts at 0
            For j As Long = 0 To nol
                fWriter.Write(shortToBytes(CStr(j).Length), 0, 2) 'Length of line number
                fWriter.Write(stringToBytes(CStr(j)), 0, CStr(j).Length) 'Line number
                fWriter.Write(byteToBytes(8), 0, 1) 'Set line number as type array (8)
                fWriter.Write(longToBytes(5), 0, 4) 'Number of values in this line
                For k As Integer = 0 To 4
                    fWriter.Write(shortToBytes(CStr(k).Length), 0, 2) 'Length of line value
                    fWriter.Write(stringToBytes(CStr(k)), 0, CStr(k).Length) 'Line value
                    fWriter.Write(byteToBytes(0), 0, 1) 'Set line value as type number (0)
                    If (k = 0) Then fWriter.Write(doubleToBytes(x1(j + lineadd)), 0, 8) 'X1
                    If (k = 1) Then fWriter.Write(doubleToBytes(y1(j + lineadd)), 0, 8) 'Y1
                    If (k = 2) Then fWriter.Write(doubleToBytes(x2(j + lineadd)), 0, 8) 'X2
                    If (k = 3) Then fWriter.Write(doubleToBytes(y2(j + lineadd)), 0, 8) 'Y2
                    If (k = 4) Then
                        fWriter.Write(doubleToBytes(0), 0, 8) 'Blank value (unknown)
                        fWriter.Write(hexStringToBytes("000009"), 0, 3) 'End this line array
                    End If
                Next
                If (j = nol) Then
                    fWriter.Write(hexStringToBytes("000009"), 0, 3) 'End this track array
                    fWriter.Write(shortToBytes(5), 0, 2) 'Length of track name ID
                    fWriter.Write(stringToBytes("label"), 0, 5) 'Track name ID
                    fWriter.Write(byteToBytes(2), 0, 1) 'Set track name ID as type string (2)
                    fWriter.Write(shortToBytes(trackName.Length), 0, 2) 'Length of track name
                    fWriter.Write(stringToBytes(trackName), 0, trackName.Length) 'Track name
                    fWriter.Write(hexStringToBytes("000009"), 0, 3) 'End track number object
                End If
            Next
            If (i = comboTrack.Items.Count - 1) Then
                fWriter.Write(hexStringToBytes("000009"), 0, 3) 'End trackList array
                fWriter.Write(byteToBytes(0), 0, 1) 'Final blank byte
                fWriter.Seek(2, IO.SeekOrigin.Begin) 'Move pointer back to filesize location
                fWriter.Write(longToBytes(My.Computer.FileSystem.GetFileInfo(fileName).Length - 6), 0, 4) 'Write total filesize of file
            End If
        Next
        fWriter.Close()
        timDrawTrack.Enabled = True
    End Sub

    'Edit
    Private Sub menuBtnSmoothCurve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim trackoffset As Integer = comboTrack.SelectedIndex
        If (trackoffset > 0) Then trackoffset = tracksep(trackoffset - 1)
        Dim num As Integer = comboLine.SelectedIndex + trackoffset
        Dim lastp As Point = New Point(0, 0)
        For i As Integer = 0 To smoothSteps
            Dim q1 As Point = blendPoints(New Point(x2(num - 1), y2(num - 1)), New Point(x1(num), y1(num)), i / smoothSteps)
            Dim q2 As Point = blendPoints(New Point(x1(num), y1(num)), New Point(x2(num), y2(num)), i / smoothSteps)
            Dim q3 As Point = blendPoints(New Point(x2(num), y2(num)), New Point(x1(num + 1), y1(num + 1)), i / smoothSteps)

            Dim r1 As Point = blendPoints(q1, q2, i / smoothSteps)
            Dim r2 As Point = blendPoints(q2, q3, i / smoothSteps)
            Dim p As Point = blendPoints(r1, r2, i / smoothSteps)

            If (i > 0) Then
                addLine(lastp.X, lastp.Y, p.X, p.Y, comboTrack.SelectedIndex, num + i)
            End If
            lastp = p
        Next
        drawTrack()
    End Sub 'Smooth curve not functional, intended to choose multiple points and smooth them together

    'View
    Private Sub menuBtnResetTrack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnResetTrack.Click
        resetOffset()
        resetZoom()
        drawTrack()
    End Sub

    'Context Menu
    Private Sub menuBtnSetStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnSetStart.Click
        If (onLine <> "-1") Then
            Dim start As Double = 0
            If (comboTrack.SelectedIndex > 0) Then start = tracksep(comboTrack.SelectedIndex - 1)
            switchLines(start, onLine)
            timDrawTrack.Enabled = True
        End If
    End Sub
    Private Sub menuBtnZoomIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnZoomIn.Click, menuBtnSZoomIn.Click
        'Set offset to zoom in to center of screen
        offsetx -= picMain.Width / 4 / zoomx
        offsety -= picMain.Height / 4 / zoomy
        'Double the zoom ratio
        zoomx *= 2
        zoomy *= 2
        timDrawTrack.Enabled = True
    End Sub
    Private Sub menuBtnZoomOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnZoomOut.Click, menuBtnSZoomOut.Click
        'Half the zoom ratio
        zoomx /= 2
        zoomy /= 2
        'Set offset to zoom out while keeping a constant center
        offsetx += picMain.Width / 4 / zoomx
        offsety += picMain.Height / 4 / zoomy
        timDrawTrack.Enabled = True
    End Sub
    Private Sub menuBtnResetZoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnResetZoom.Click, menuBtnSResetZoom.Click
        resetOffset()
        resetZoom()
        drawTrack()
    End Sub

    Private Sub comboTrack_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles comboTrack.SelectedIndexChanged
        Me.Text = "LR Tools: " & comboTrack.SelectedItem
        refreshLineList()
        If (comboLine.Items.Count >= 1) Then comboLine.SelectedIndex = 0
        drawTrack()
    End Sub
    Private Sub comboLine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles comboLine.SelectedIndexChanged
        If (changeTo <> -1) Then
            comboLine.SelectedIndex = changeTo
            changeTo = -1
        End If
        If (comboLine.SelectedIndex = -1) Then Exit Sub
        Dim trackoffset As Integer = comboTrack.SelectedIndex
        If (trackoffset > 0) Then trackoffset = tracksep(trackoffset - 1)
        Dim num As Integer = comboLine.SelectedIndex + trackoffset
        txtX1.Text = x1(num)
        txtY1.Text = y1(num)
        txtX2.Text = x2(num)
        txtY2.Text = y2(num)
        If (dontCenterPoint = False) Then centerPoint((x1(num) + x2(num)) / 2, (y1(num) + y2(num)) / 2)
        statusLblLineSlope.Text = "Line Slope: " & Math.Round(y2(num) - y1(num), 2) & "/" & Math.Round(x2(num) - x1(num), 2)
        statusLblLineLength.Text = "Line Length: " & Math.Round(distanceBetween(x1(num), y1(num), x2(num), y2(num)), 2)
        drawTrack()
    End Sub

    Private Sub picMain_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picMain.MouseMove
        If (pressedOnPic = True) Then
            Dim thisx As Double = e.Location.X / zoomx - offsetx
            Dim thisy As Double = e.Location.Y / zoomy - offsety
            'If mouse button is pressed
            If (radTrackMove.Checked = True) Then
                offsetx = (e.Location.X - trackMoveStart.X) / zoomx + origoffsetx
                offsety = (e.Location.Y - trackMoveStart.Y) / zoomy + origoffsety
                drawTrack()
            ElseIf (radTrackDraw.Checked = True) Then
                If (radDrawLines.Checked = True) Then
                    If (distanceBetween(lastx, lasty, thisx, thisy) >= minline / ((zoomx + zoomy) / 2)) Then
                        addLine(lastx, lasty, thisx, thisy, comboTrack.SelectedIndex)
                        lastx = thisx
                        lasty = thisy
                    End If
                    Dim thisTrack As Integer = 0
                    If (comboTrack.SelectedIndex <> -1) Then thisTrack = comboTrack.SelectedIndex
                    drawSelectedLine = False
                    drawTrack(False, tracksep(thisTrack) - 1)
                    drawSelectedLine = True
                End If
            ElseIf (radTrackErase.Checked = True) Then
                Dim start As Double = 0
                If (comboTrack.SelectedIndex > 0) Then start = tracksep(comboTrack.SelectedIndex - 1)
                Dim finish As Double = tracksep(comboTrack.SelectedIndex) - 1
                Dim didRemove As Boolean = False
                For i As Integer = start To finish
                    For j As Integer = 0 To eraseChecks
                        If (distanceBetween(blendDoubles(x1(i), x2(i), j / eraseChecks), blendDoubles(y1(i), y2(i), j / eraseChecks), thisx, thisy) < eraseSensitivity / ((zoomx + zoomy) / 2)) Then
                            removeLine(i)
                            didRemove = True
                        End If
                    Next
                Next
                If (didRemove = True) Then drawTrack()
                'drawTrack()
                eraseSensitivity -= 1 'Make circle smaller so erasing circle doesn't accidentally...
                trackGraphics.DrawEllipse(New Pen(Color.White, 3), lastmp.X - eraseSensitivity, lastmp.Y - eraseSensitivity, eraseSensitivity * 2, eraseSensitivity * 2)
                trackGraphics.DrawEllipse(Pens.Red, e.Location.X - eraseSensitivity, e.Location.Y - eraseSensitivity, eraseSensitivity * 2, eraseSensitivity * 2)
                eraseSensitivity += 1 '...erase part of a line (make circle bigger again)
                lastmp = e.Location
            ElseIf (radTrackSelect.Checked = True) Then
                If (e.Button = Windows.Forms.MouseButtons.Left And onLine <> -1) Then
                    'Moving the mouse with a line selected
                    x1(onLine) = thisx + offx1
                    y1(onLine) = thisy + offy1
                    x2(onLine) = thisx + offx2
                    y2(onLine) = thisy + offy2
                    drawTrack()
                ElseIf (e.Button = Windows.Forms.MouseButtons.Left) Then
                    'Moving the mouse without a line selected
                    If (lineArea <> New Rectangle(0, 0, 0, 0)) Then
                        lineArea.Width = thisx - lineArea.X
                        lineArea.Height = thisy - lineArea.Y
                        drawTrack()
                        Dim rectPen As Pen = New Pen(Color.Blue, 2)
                        rectPen.DashStyle = Drawing2D.DashStyle.Dash
                        trackGraphics.DrawRectangle(rectPen, lineArea)
                    End If
                End If
            End If
        Else
            'If mouse button is not pressed
            If (radTrackDraw.Checked = True And radDrawBeziers.Checked = True) Then
                If (lastxxx <> 0 And lastxx <> 0 And drawNext = True) Then
                    trackGraphics.Clear(Color.White)
                    drawTrack()

                    'Dim thisx As Double = e.Location.X / zoomx - offsetx
                    'Dim thisy As Double = e.Location.Y / zoomy - offsety

                    'If (slope(lastx, lasty, thisx, thisy) < 0) Then
                    '    trackGraphics.DrawBezier(New Pen(Color.Red, 3), lastx, lasty, thisx, lasty, thisx, thisy, thisx, thisy)
                    '    trackGraphics.FillEllipse(Brushes.Gray, CInt(thisx - 2), CInt(lasty - 2), 4, 4)
                    'Else
                    '    trackGraphics.DrawBezier(New Pen(Color.Red, 3), lastx, lasty, lastx, thisy, thisx, thisy, thisx, thisy)
                    '    trackGraphics.FillEllipse(Brushes.Gray, CInt(lastx - 2), CInt(thisy - 2), 4, 4)
                    'End If

                    'If (draw3D = True) Then trackGraphics.DrawBezier(New Pen(Color.Gray, 3), (lastxxx + offsetx) * zoomx + 2, (lastyyy + offsety) * zoomy + 2, (lastxx + offsetx) * zoomx + 2, (lastyy + offsety) * zoomy + 2, e.Location.X + 2, e.Location.Y + 2, e.Location.X + 2, e.Location.Y + 2)

                    'trackGraphics.FillEllipse(Brushes.Black, CInt(lastx - 2), CInt(lasty - 2), 4, 4)
                    'trackGraphics.FillEllipse(Brushes.Black, CInt(thisx - 2), CInt(thisy - 2), 4, 4)

                    trackGraphics.DrawBezier(New Pen(Color.Red, 3), CInt((lastxxx + offsetx) * zoomx), CInt((lastyyy + offsety) * zoomy), CInt((lastxx + offsetx) * zoomx), CInt((lastyy + offsety) * zoomy), e.Location.X, e.Location.Y, e.Location.X, e.Location.Y)
                    trackGraphics.FillEllipse(Brushes.Black, CInt((lastxxx + offsetx) * zoomx - 2), CInt((lastyyy + offsety) * zoomy - 2), 4, 4)
                    trackGraphics.FillEllipse(Brushes.Black, CInt((lastxx + offsetx) * zoomx - 2), CInt((lastyy + offsety) * zoomy - 2), 4, 4)
                    trackGraphics.FillEllipse(Brushes.Black, e.Location.X - 2, e.Location.Y - 2, 4, 4)

                    'lastmp = e.Location
                End If
            ElseIf (radTrackSelect.Checked = True) Then
                Dim thisx As Double = e.Location.X / zoomx - offsetx
                Dim thisy As Double = e.Location.Y / zoomy - offsety
                Dim start As Double = 0
                If (comboTrack.SelectedIndex > 0) Then start = tracksep(comboTrack.SelectedIndex - 1)
                Dim finish As Double = tracksep(comboTrack.SelectedIndex) - 1
                onLine = -1
                Dim lowestDist As Double = 1000
                For i As Integer = start To finish
                    For j As Integer = 0 To selectChecks
                        Dim dist As Double = distanceBetween(blendDoubles(x1(i), x2(i), j / selectChecks), blendDoubles(y1(i), y2(i), j / selectChecks), thisx, thisy)
                        If (dist < selectSensitivity / ((zoomx + zoomy) / 2)) Then
                            onLine = i
                            GoTo foundMatch
                        End If
                    Next
                Next
foundMatch:
                If (onLine <> -1) Then
                    picMain.Cursor = Cursors.SizeAll
                    dontCenterPoint = True
                    comboLine.SelectedIndex = onLine - start
                    dontCenterPoint = False
                    menuBtnSetStart.Enabled = True
                Else
                    picMain.Cursor = Cursors.Default
                    menuBtnSetStart.Enabled = False
                End If
            End If
        End If
        statusLblPosition.Text = "Mouse Position: (" & Math.Round(e.Location.X / zoomx - offsetx, 2) & ", " & Math.Round(e.Location.Y / zoomy - offsety, 2) & ")"
    End Sub
    Private Sub picMain_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picMain.MouseDown
        trackMoveStart = e.Location
        If (radTrackMove.Checked = True) Then
            origoffsetx = offsetx
            origoffsety = offsety
        ElseIf (radTrackDraw.Checked = True) Then
            lastx = e.Location.X / zoomx - offsetx
            lasty = e.Location.Y / zoomy - offsety
        ElseIf (radTrackErase.Checked = True) Then
            lastmp = e.Location
        End If

        Dim thisx As Double = e.Location.X / zoomx - offsetx
        Dim thisy As Double = e.Location.Y / zoomy - offsety

        If (radDrawBeziers.Checked = True And radTrackDraw.Checked = True) Then
            If (e.Button = Windows.Forms.MouseButtons.Left) Then

                ' >>>Bezier calculation formula based on a right angle
                '                lastxx = x1(tracksep(comboTrack.SelectedIndex) - 1)
                '                lastyy = y1(tracksep(comboTrack.SelectedIndex) - 1)
                '                lastx = x2(tracksep(comboTrack.SelectedIndex) - 1)
                '                lasty = y2(tracksep(comboTrack.SelectedIndex) - 1)

                '                'Calculate a bezier based on three points, attempting to use a real point[lastx],
                '                'the mouse point as an anchor[thisx], and an imaginary point as control

                '                If (lastxx = lastx And lastyy = lasty) Then GoTo skipBezier

                '                Dim bezierSteps As Integer = Math.Ceiling(distanceBetween(lastx, lasty, thisx, thisy) / minline / ((zoomx + zoomy) / 2))
                '                Dim lastpx As Double = 0
                '                Dim lastpy As Double = 0
                '                For i As Integer = 0 To bezierSteps
                '                    Dim p1 As Point = New Point(0, 0)
                '                    Dim p2 As Point = New Point(0, 0)
                '                    If (slope(lastx, lasty, thisx, thisy) < 0) Then
                '                        p1 = blendPoints(New Point(lastx, lasty), New Point(thisx, lasty), i / bezierSteps)
                '                        p2 = blendPoints(New Point(thisx, lasty), New Point(thisx, thisy), i / bezierSteps)
                '                    Else
                '                        p1 = blendPoints(New Point(lastx, lasty), New Point(lastx, thisy), i / bezierSteps)
                '                        p2 = blendPoints(New Point(lastx, thisy), New Point(thisx, thisy), i / bezierSteps)
                '                    End If
                '                    Dim px As Double = blendDoubles(p1.X, p2.X, i / bezierSteps)
                '                    Dim py As Double = blendDoubles(p1.Y, p2.Y, i / bezierSteps)
                '                    If (lastpx = 0 And lastpy = 0) Then
                '                        addLine(lastx, lasty, px, py, comboTrack.SelectedIndex)
                '                    Else
                '                        addLine(lastpx, lastpy, px, py, comboTrack.SelectedIndex)
                '                    End If
                '                    If (i = bezierSteps) Then changeTo = comboLine.Items.Count
                '                    lastpx = px
                '                    lastpy = py
                '                Next
                'skipBezier:

                '>>>Bezier calculation formula based on last point and two user-defined points
                Dim lastpx As Double = 0
                Dim lastpy As Double = 0

                Dim bezierSteps As Integer = 20
                bezierSteps = Math.Floor(distanceBetween(lastxxx, lastyyy, lastx, lasty)) / minline / ((zoomx + zoomy) / 2)
                If (drawNext = True) Then
                    If (lastxxx <> 0 And lastxx <> 0) Then
                        For i As Integer = 0 To bezierSteps
                            Dim p1 As Point = blendPoints(New Point(lastxxx, lastyyy), New Point(lastxx, lastyy), i / bezierSteps)
                            Dim p2 As Point = blendPoints(New Point(lastxx, lastyy), New Point(lastx, lasty), i / bezierSteps)
                            Dim px As Double = blendDoubles(p1.X, p2.X, i / bezierSteps)
                            Dim py As Double = blendDoubles(p1.Y, p2.Y, i / bezierSteps)
                            If (lastpx = 0 And lastpy = 0) Then
                                addLine(lastxxx, lastyyy, px, py, comboTrack.SelectedIndex)
                            Else
                                addLine(lastpx, lastpy, px, py, comboTrack.SelectedIndex)
                            End If
                            If (i = bezierSteps) Then changeTo = comboLine.Items.Count + bezierSteps
                            lastpx = px
                            lastpy = py
                            drawNext = False
                            'addLine(blendDoubles(lastxx, lastx, i / bezierSteps), blendDoubles(lastyy, lasty, i / bezierSteps), blendDoubles(lastx, thisx, i / bezierSteps), blendDoubles(lasty, thisy, i / bezierSteps), comboTrack.SelectedIndex)
                        Next
                        lastpx = 0
                        lastpy = 0
                        drawTrack()
                    End If
                Else
                    drawNext = True
                End If
                lastxxx = lastxx
                lastyyy = lastyy
                lastxx = lastx
                lastyy = lasty
                lastx = thisx
                lasty = thisy
            ElseIf (e.Button = Windows.Forms.MouseButtons.Middle) Then
                lastxxx = 0
                lastyyy = 0
                lastxx = 0
                lastyy = 0
                lastx = 0
                lasty = 0
                trackGraphics.Clear(Color.Green)
                timDrawTrack.Enabled = True
            End If
        End If
        If (radTrackSelect.Checked = True) Then
            If (onLine <> -1) Then
                'Selected a line
                offx1 = x1(onLine) - thisx
                offy1 = y1(onLine) - thisy
                offx2 = x2(onLine) - thisx
                offy2 = y2(onLine) - thisy
            Else
                'Begin selecting multiple lines
                lineArea.X = thisx
                lineArea.Y = thisy
            End If
        End If
            pressedOnPic = True
            timDrawTrack.Enabled = True
    End Sub
    Private Sub picMain_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picMain.MouseUp
        If (pressedOnPic = True) Then
            If (radTrackMove.Checked = True) Then
                origoffsetx = e.Location.X - trackMoveStart.X + origoffsetx
                origoffsety = e.Location.Y - trackMoveStart.Y + origoffsety
            ElseIf (radTrackDraw.Checked = True Or radTrackErase.Checked = True) Then
                Dim oldIndex As Integer = comboLine.SelectedIndex
                refreshLineList()
                dontCenterPoint = True
                Try
                    comboLine.SelectedIndex = oldIndex
                Catch
                    comboLine.SelectedIndex = -1
                End Try
                dontCenterPoint = False
                drawTrack()
            ElseIf (radTrackSelect.Checked = True) Then
                'Dim thisx As Double = e.Location.X / zoomx - offsetx
                'Dim thisy As Double = e.Location.Y / zoomy - offsety
                'lineArea.Width = thisx - lineArea.X
                'lineArea.Height = thisy - lineArea.Y
                Dim begin As Double = 0
                If (comboTrack.SelectedIndex > 0) Then begin = tracksep(comboTrack.SelectedIndex - 1)
                For i As Integer = 0 To onLines.Length - 1
                    onLines(i) = Nothing
                Next
                Dim counter As Double = 0
                For i As Integer = begin To tracksep(comboTrack.SelectedIndex) - 1
                    If (inRectangle(x1(i), y1(i), lineArea) Or inRectangle(x2(i), y2(i), lineArea)) Then
                        onLines(i) = counter
                        counter += 1
                    End If
                Next
                lineArea = New Rectangle(0, 0, 0, 0)
            End If
        End If
        pressedOnPic = False
    End Sub
    Private Sub picMain_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles picMain.Paint
        If (Me.Focused = True) Then drawTrack()
    End Sub

    Private Sub radTrackMove_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radTrackMove.CheckedChanged
        If (radTrackMove.Checked = True) Then picMain.Cursor = Cursors.SizeAll
    End Sub
    Private Sub radTrackDraw_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radTrackDraw.CheckedChanged
        If (radTrackDraw.Checked = True) Then picMain.Cursor = Cursors.Cross
    End Sub
    Private Sub radTrackErase_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radTrackErase.CheckedChanged
        If (radTrackErase.Checked = True) Then picMain.Cursor = Cursors.Default
    End Sub
    Private Sub radTrackSelect_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radTrackSelect.CheckedChanged
        If (radTrackSelect.Checked = True) Then
            picMain.Cursor = Cursors.Default
            picMain.ContextMenuStrip = conMenuSelect
        Else
            picMain.ContextMenuStrip = conMenuMain
        End If
    End Sub

    Private Sub timDrawTrack_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timDrawTrack.Tick
        drawTrack()
        timDrawTrack.Enabled = False
    End Sub

    Private Function readLength(ByVal reader As System.IO.FileStream) As Integer
        Return (256 * reader.ReadByte()) + reader.ReadByte()
    End Function
    Private Function readFour(ByVal reader As System.IO.FileStream) As Double
        Dim b1 As Double = reader.ReadByte()
        Dim b2 As Double = reader.ReadByte()
        Dim b3 As Double = reader.ReadByte()
        Dim b4 As Double = reader.ReadByte()
        b1 *= 16777216
        b2 *= 65536
        b3 *= 256
        Return b1 + b2 + b3 + b4
    End Function
    Private Function readString(ByVal reader As System.IO.FileStream, ByVal length As Integer) As String
        Dim ret As String = ""
        For i As Integer = 1 To length
            ret &= Chr(reader.ReadByte)
        Next
        Return ret
    End Function
    Private Function readHexString(ByVal reader As System.IO.FileStream, ByVal length As Integer) As String
        Dim ret As String = ""
        For i As Integer = 1 To length
            Dim t As String = Hex(reader.ReadByte)
            If (t.Length < 2) Then t = "0" & t
            ret &= t
        Next
        Return ret
    End Function

    Private Function doubleToBytes(ByVal num As Double) As Byte()
        Dim ret(7) As Byte
        CopyMemory2(ret(0), num, 8) 'Convert double to bytes
        Array.Reverse(ret) 'Reverse array for Big Endian (sig/small values first)
        Return ret
    End Function
    Private Function longToBytes(ByVal num As Long) As Byte()
        Dim ret(3) As Byte
        ret(0) = Math.Floor(num / 16777216)
        ret(1) = Math.Floor(num / 65536)
        ret(2) = Math.Floor(num / 256)
        ret(3) = num Mod 256
        Return ret
    End Function
    Private Function byteToBytes(ByVal b As Byte) As Byte()
        Dim ret(0) As Byte
        ret(0) = b
        Return ret
    End Function
    Private Function shortToBytes(ByVal num As Short) As Byte()
        Dim ret(1) As Byte
        ret(0) = Math.Floor(num / 256)
        ret(1) = num Mod 256
        Return ret
    End Function
    Private Function stringToDouble(ByVal str As String) As Double
        'Performs a Big Endian swap on string as array
        Dim b(7) As Byte
        Dim f As Double
        b(0) = CInt("&H" & Mid(str, 1, 2))
        b(1) = CInt("&H" & Mid(str, 3, 2))
        b(2) = CInt("&H" & Mid(str, 5, 2))
        b(3) = CInt("&H" & Mid(str, 7, 2))
        b(4) = CInt("&H" & Mid(str, 9, 2))
        b(5) = CInt("&H" & Mid(str, 11, 2))
        b(6) = CInt("&H" & Mid(str, 13, 2))
        b(7) = CInt("&H" & Mid(str, 15, 2))
        Array.Reverse(b) 'Reverse array for Big Endian (sig/small values first)
        CopyMemory(f, b(0), 8)
        Return f
    End Function
    Private Function hexStringToBytes(ByVal hexString As String) As Byte()
        Dim ret(hexString.Length / 2 - 1) As Byte
        For i As Integer = 0 To hexString.Length / 2 - 1
            ret(i) = CInt("&H" & Mid(hexString, i * 2 + 1, 2))
        Next
        Return ret
    End Function
    Private Function stringToBytes(ByVal str As String) As Byte()
        Dim ret(str.Length - 1) As Byte
        For i As Integer = 0 To str.Length - 1
            ret(i) = Asc(Mid(str, i + 1, 1))
        Next
        Return ret
    End Function

    Private Function slope(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As Double
        Return (y2 - y1) / (x2 - x1)
    End Function
    Private Function inset() As String
        Dim ret As String = ""
        If (arrayInset > 0) Then
            For i As Integer = 1 To arrayInset * arrayTabspace
                ret &= " "
            Next
        End If
        Return ret
    End Function
    Private Sub drawTrack(Optional ByVal clear As Boolean = True, Optional ByVal start As Double = 0, Optional ByVal lineskip As Integer = 1)
        If (comboTrack.SelectedIndex = -1) Then Exit Sub

        Dim g As Graphics = trackGraphics
        If (clear = True) Then g.Clear(Color.White)

        'Checks to see which save file we are drawing
        Dim begin As Double = 0
        Dim customStart = False
        If (start > 0) Then
            begin = start
            customStart = True
        Else
            If (comboTrack.SelectedIndex > 0) Then begin = tracksep(comboTrack.SelectedIndex - 1)
        End If

        Dim j As Double = comboLine.SelectedIndex + begin
        If (drawSelectedLine = True) Then
            If (comboLine.SelectedIndex <> -1) Then
                Dim thisPen As Pen = New Pen(Color.FromArgb("200", "200", "255"), 1)
                thisPen.DashStyle = Drawing2D.DashStyle.Dash
                Dim xx1 As Double = (x1(j) + offsetx) * zoomx
                Dim yy1 As Double = (y1(j) + offsety) * zoomy
                Dim xx2 As Double = (x2(j) + offsetx) * zoomx
                Dim yy2 As Double = (y2(j) + offsety) * zoomy
                Dim xxx1 As Integer = xx1 - (xx2 - xx1) * predictLength
                Dim yyy1 As Integer = yy1 - (yy2 - yy1) * predictLength
                Dim xxx2 As Integer = xx2 + (xx2 - xx1) * predictLength
                Dim yyy2 As Integer = yy2 + (yy2 - yy1) * predictLength
                g.DrawLine(thisPen, xxx1, yyy1, xxx2, yyy2)
            End If
        End If

        If (customStart = False) Then begin += 1
        'begin += 1
        'Regular drawing mode, fastest for small files, draws all lines
        If (tracksep(comboTrack.SelectedIndex) - begin >= 0) Then
            ReDim linesa(tracksep(comboTrack.SelectedIndex) - begin)
            ReDim linesb(tracksep(comboTrack.SelectedIndex) - begin)
            For i As Double = begin To tracksep(comboTrack.SelectedIndex) - 1
                linesa(i - begin) = New Point(CInt((x1(i) + offsetx) * zoomx), CInt((y1(i) + offsety) * zoomy))
                linesb(i - begin) = New Point(CInt((x2(i) + offsetx) * zoomx), CInt((y2(i) + offsety) * zoomy))
            Next
            For i As Integer = 0 To linesa.Length - 1
                g.DrawLine(Pens.Black, linesa(i), linesb(i))
            Next
            'For i As Double = begin To tracksep(comboTrack.SelectedIndex) - 1 Step lineskip
            '    g.DrawLine(Pens.Black, CInt((x1(i) + offsetx) * zoomx), CInt((y1(i) + offsety) * zoomy), CInt((x2(i) + offsetx) * zoomx), CInt((y2(i) + offsety) * zoomy))
            'Next

            If (drawSelectedLine = True) Then
                If (comboLine.SelectedIndex <> -1) Then
                    Dim newPen As Pen = New Pen(Color.Red, 3)
                    g.DrawLine(newPen, CInt((x1(j) + offsetx) * zoomx), CInt((y1(j) + offsety) * zoomy), CInt((x2(j) + offsetx) * zoomx), CInt((y2(j) + offsety) * zoomy))
                End If
            End If
            If (customStart = False) Then g.DrawLine(New Pen(Color.Green, 3), CInt((x1(begin - 1) + offsetx) * zoomx), CInt((y1(begin - 1) + offsety) * zoomy), CInt((x2(begin - 1) + offsetx) * zoomx), CInt((y2(begin - 1) + offsety) * zoomy))

        End If

        statusLblOffset.Text = "Offset: (" & Math.Round(offsetx, 2) & ", " & Math.Round(offsety, 2) & ")"
        statusLblZoom.Text = "Zoom: " & Math.Round((zoomx / 1) * 100, 2) & "% x " & Math.Round((zoomy / 1) * 100, 2) & "%"
    End Sub
    Private Sub resetOffset()
        offsetx = 0
        offsety = 0
    End Sub
    Private Sub resetZoom()
        zoomx = 1
        zoomy = 1
    End Sub
    Private Sub centerPoint(ByVal x As Double, ByVal y As Double)
        offsetx = (picMain.Width / 2) / zoomx - x
        offsety = (picMain.Height / 2) / zoomy - y
    End Sub
    Private Function inBounds(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double, ByVal both As Boolean) As Boolean
        If (both = False) Then
            If (inBounds2((x1 + offsetx) * zoomx, (y1 + offsety) * zoomy) = True Or inBounds2((x2 + offsetx) * zoomx, (y2 + offsety) * zoomy) = True) Then Return True Else Return False
        Else
            If (inBounds2((x1 + offsetx) * zoomx, (y1 + offsety) * zoomy) = True And inBounds2((x2 + offsetx) * zoomx, (y2 + offsety) * zoomy) = True) Then Return True Else Return False
        End If
    End Function
    Private Function inBounds2(ByVal x As Double, ByVal y As Double) As Boolean
        If (x >= 0 And x < picMain.Width And y >= 0 And y < picMain.Height) Then Return True Else Return False
    End Function
    Private Function inRectangle(ByVal xx As Double, ByVal yy As Double, ByVal rect As Rectangle) As Boolean
        If (xx > rect.X And xx < rect.X + rect.Width And yy > rect.Y And yy < rect.Y + rect.Height) Then Return True Else Return False
    End Function

    Private Function blendPoints(ByVal point1 As Point, ByVal point2 As Point, ByVal amount As Double) As Point
        Dim x As Integer = (point2.X * amount) + (point1.X * (1 - amount))
        Dim y As Integer = (point2.Y * amount) + (point1.Y * (1 - amount))
        Return New Point(x, y)
    End Function
    Private Function blendDoubles(ByVal d1 As Double, ByVal d2 As Double, ByVal amount As Double) As Double
        Return (d2 * amount) + (d1 * (1 - amount))
    End Function

    Private Sub refreshLineList()
        comboLine.Items.Clear()
        Dim begin As Double = 0
        If (comboTrack.SelectedIndex > 0) Then begin = tracksep(comboTrack.SelectedIndex - 1)
        For i As Integer = begin To tracksep(comboTrack.SelectedIndex) - 1
            comboLine.Items.Add(i - begin)
        Next
    End Sub
    Private Sub addLine(ByVal xa As Double, ByVal ya As Double, ByVal xb As Double, ByVal yb As Double, ByVal track As Double, Optional ByVal afterLine As Double = -1)
        If (track = -1) Then Exit Sub 'Exit if not drawing on a track
        If (xa = ya And xb = yb) Then Exit Sub 'Exit if line is just a dot
        Dim addto As Double = 0
        If (afterLine = -1) Then addto = tracksep(track) Else addto = afterLine
        x1 = moveArrayUp(x1, addto)
        x2 = moveArrayUp(x2, addto)
        y1 = moveArrayUp(y1, addto)
        y2 = moveArrayUp(y2, addto)
        line = moveIArrayUp(line, addto)
        For i As Integer = track To comboTrack.Items.Count - 1
            tracksep(i) += 1
        Next

        x1(addto) = xa
        y1(addto) = ya
        x2(addto) = xb
        y2(addto) = yb
        line(addto) = track
        'Dim thisoffset As Double = 0
        'If (track > 0) Then thisoffset = tracksep(track - 1)
    End Sub
    Private Sub removeLine(ByVal lineNumber As Double)
        If (comboTrack.SelectedIndex = -1) Then Exit Sub 'Exit if no track is selected
        Dim linenum As Double = 0
        If (lineNumber = -1) Then linenum = tracksep(comboTrack.SelectedIndex) Else linenum = lineNumber
        x1 = moveArrayDown(x1, linenum)
        x2 = moveArrayDown(x2, linenum)
        y1 = moveArrayDown(y1, linenum)
        y2 = moveArrayDown(y2, linenum)
        line = moveIArrayDown(line, linenum)
        For i As Integer = comboTrack.SelectedIndex To comboTrack.Items.Count - 1
            tracksep(i) -= 1
        Next
        Dim trackadd As Double = 0
        If (comboTrack.SelectedIndex > 0) Then trackadd = tracksep(comboTrack.SelectedIndex - 1)
        If (comboLine.SelectedIndex + trackadd >= linenum) Then
            dontCenterPoint = True
            comboLine.SelectedIndex -= 1
            dontCenterPoint = False
        End If
    End Sub
    Private Sub switchLines(ByVal line1 As Double, ByVal line2 As Double)
        Dim tmp(3) As Double
        tmp(0) = x1(line2)
        tmp(1) = y1(line2)
        tmp(2) = x2(line2)
        tmp(3) = y2(line2)
        x1(line2) = x1(line1)
        y1(line2) = y1(line1)
        x2(line2) = x2(line1)
        y2(line2) = y2(line1)
        x1(line1) = tmp(0)
        y1(line1) = tmp(1)
        x2(line1) = tmp(2)
        y2(line1) = tmp(3)
    End Sub
    Private Function moveArrayUp(ByVal ar() As Double, ByVal position As Double, Optional ByVal amount As Integer = 1) As Double()
        Dim ret(ar.Length) As Double
        For i As Integer = 0 To ret.Length - amount
            If (i < position) Then
                ret(i) = ar(i)
            ElseIf (i >= position + amount) Then
                ret(i) = ar(i - amount)
            End If
        Next
        Return ret
    End Function
    Private Function moveArrayDown(ByVal ar() As Double, ByVal position As Double, Optional ByVal amount As Integer = 1) As Double()
        Dim ret(ar.Length - amount - 1) As Double
        For i As Integer = 0 To ret.Length - 1
            If (i < position) Then
                ret(i) = ar(i)
            ElseIf (i >= position) Then
                ret(i) = ar(i + amount)
            End If
        Next
        Return ret
    End Function
    Private Function moveIArrayUp(ByVal ar() As Integer, ByVal position As Double, Optional ByVal amount As Integer = 1) As Integer()
        Dim ret(ar.Length) As Integer
        For i As Integer = 0 To ret.Length - amount
            If (i < position) Then
                ret(i) = ar(i)
            ElseIf (i >= position + amount) Then
                ret(i) = ar(i - amount)
            End If
        Next
        Return ret
    End Function
    Private Function moveIArrayDown(ByVal ar() As Integer, ByVal position As Double, Optional ByVal amount As Integer = 1) As Integer()
        Dim ret(ar.Length - amount - 1) As Integer
        For i As Integer = 0 To ret.Length - 1
            If (i < position) Then
                ret(i) = ar(i)
            ElseIf (i >= position) Then
                ret(i) = ar(i + amount)
            End If
        Next
        Return ret
    End Function
    Private Function moveSArrayUp(ByVal ar() As String, ByVal position As Double, Optional ByVal amount As Integer = 1) As String()
        Dim ret(ar.Length) As String
        For i As Integer = 0 To ret.Length - amount
            If (i < position) Then
                ret(i) = ar(i)
            ElseIf (i >= position + amount) Then
                ret(i) = ar(i - amount)
            End If
        Next
        Return ret
    End Function
    Private Function moveSArrayDown(ByVal ar() As String, ByVal position As Double, Optional ByVal amount As Integer = 1) As String()
        Dim ret(ar.Length - amount - 1) As String
        For i As Integer = 0 To ret.Length - 1
            If (i < position) Then
                ret(i) = ar(i)
            ElseIf (i >= position) Then
                ret(i) = ar(i + amount)
            End If
        Next
        Return ret
    End Function
    Private Function distanceBetween(ByVal xa As Double, ByVal ya As Double, ByVal xb As Double, ByVal yb As Double) As Double
        Return Math.Sqrt((xb - xa) ^ 2 + (yb - ya) ^ 2)
    End Function

    Public Sub testDirectories()
        If (My.Computer.FileSystem.FileExists(settingsFile) = False) Then
            If (My.Computer.FileSystem.DirectoryExists(programFiles & "\" & company & "\" & program) = False) Then
                If (My.Computer.FileSystem.DirectoryExists(programFiles & "\" & company) = False) Then
                    If (My.Computer.FileSystem.DirectoryExists(programFiles) = False) Then
                        My.Computer.FileSystem.CreateDirectory(programFiles)
                    End If
                    My.Computer.FileSystem.CreateDirectory(programFiles & "\" & company)
                End If
                My.Computer.FileSystem.CreateDirectory(programFiles & "\" & company & "\" & program)
            End If
            My.Computer.FileSystem.WriteAllText(settingsFile, "", False)
        End If
    End Sub
    Public Sub loadSettings()
        If (My.Computer.FileSystem.FileExists(settingsFile) = True) Then
            'If (My.Computer.FileSystem.ReadAllText(settingsFile) <> "") Then Exit Sub
retry:
            Dim solDir As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\Macromedia\Flash Player\#SharedObjects"
            Dim solNum As String = ""
            Dim solFla As String = ""
            For Each dirnum As String In My.Computer.FileSystem.GetDirectories(solDir)
                solNum = Mid(dirnum, dirnum.LastIndexOf("\") + 2)
                Exit For
            Next
            lrSite = My.Computer.FileSystem.ReadAllText(settingsFile)
            siteList = solDir & "\" & solNum
            If (lrSite = "") Then
                If (formSite.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                    lrSite = formSite.returnSite
                End If
            End If
            For Each dirnum As String In My.Computer.FileSystem.GetDirectories(solDir & "\" & solNum & "\" & lrSite)
                solFla = Mid(dirnum, dirnum.LastIndexOf("\") + 2)
                Exit For
            Next
            trackPath = solDir & "\" & solNum & "\" & lrSite & "\" & solFla
            solDir = trackPath & "\undefined.sol"
            openFileMain.FileName = solDir
            saveSettings()
        Else
            testDirectories()
        End If
    End Sub
    Public Sub saveSettings()
        Try
            My.Computer.FileSystem.WriteAllText(settingsFile, lrSite, False)
        Catch ex As Exception
            MsgBox("Unable to save settings." & vbCrLf & vbCrLf & "Error: " & ex.Message, MsgBoxStyle.Critical, "Error: Cannot save settings")
        End Try
    End Sub

    Private Sub menuBtnNetwork_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnNetwork.Click
        'Hide main window and show Line Rider Network
        Me.Visible = False
        formNetwork.ShowDialog()
    End Sub

    Private Sub menuBtnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnAbout.Click
        MsgBox("About LR Tools (BETA)" & vbCrLf & "Created by TheWandererLee" & vbCrLf & vbCrLf & "Version 1.0 BETA" & vbCrLf & vbCrLf & "Contact me at: DC@xaranda.net", MsgBoxStyle.Information, "About LR Tools")
    End Sub

    Private Sub menuBtnAddTrack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnAddTrack.Click
        addTrack()
    End Sub
    Private Sub menuBtnRenameTrack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnRenameTrack.Click
        If (comboTrack.SelectedIndex = -1) Then
            MsgBox("You must first select a track to rename.", MsgBoxStyle.Exclamation, "Select a Track")
        Else
            formInput.txtInput.Text = comboTrack.SelectedItem
            If (formInput.ShowDialog = Windows.Forms.DialogResult.OK) Then
                comboTrack.Items.Item(comboTrack.SelectedIndex) = formInput.txtInput.Text
                tracks(comboTrack.SelectedIndex) = formInput.txtInput.Text
            End If
            timDrawTrack.Enabled = True
        End If
    End Sub
    Private Sub menuBtnRemoveTrack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuBtnRemoveTrack.Click
        If (comboTrack.SelectedIndex >= 0) Then
            If (MsgBox("Are you sure you want to delete the track " & vbQuote & comboTrack.SelectedItem & vbQuote & "?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Delete Track " & comboTrack.SelectedItem) = MsgBoxResult.Yes) Then
                removeTrack(comboTrack.SelectedIndex)
            End If
        Else
            MsgBox("You must select a track to delete.", MsgBoxStyle.Exclamation, "Select a Track to Delete")
        End If
    End Sub

    Private Sub addTrack(Optional ByVal name As String = "Untitled")
        Dim addTrackAt As Integer = 0
        For i As Integer = 0 To tracks.Length - 1
            If (tracks(i) = Nothing) Then
                addTrackAt = i
                Exit For
            End If
        Next
        Dim lastLine As Double = 0
        For i As Double = 0 To line.Length - 1
            If (line(i) = Nothing) Then
                lastLine = i + 1
                Exit For
            End If
        Next
        formInput.txtInput.Text = "Track " & addTrackAt + 1
        If (name <> "Untitled") Then formInput.txtInput.Text = name
        If (formInput.ShowDialog = Windows.Forms.DialogResult.OK) Then
            comboTrack.Items.Add(formInput.txtInput.Text)
            comboTrack.SelectedIndex = addTrackAt
            tracks = moveSArrayUp(tracks, addTrackAt)
            tracks(addTrackAt) = formInput.txtInput.Text
            If (addTrackAt = 0) Then tracksep(addTrackAt) = 0 Else tracksep(addTrackAt) = tracksep(addTrackAt - 1)
            If (pnlTrack.Enabled = False) Then pnlTrack.Enabled = True
        End If
        timDrawTrack.Enabled = True
    End Sub
    Private Sub removeTrack(ByVal trackID As Integer)
        Dim trackStart As Double = 0
        If (trackID > 0) Then trackStart = tracksep(trackID - 1)
        Dim trackEnd As Double = tracksep(trackID)
        x1 = moveArrayDown(x1, trackStart, trackEnd - trackStart)
        y1 = moveArrayDown(y1, trackStart, trackEnd - trackStart)
        x2 = moveArrayDown(x2, trackStart, trackEnd - trackStart)
        y2 = moveArrayDown(y2, trackStart, trackEnd - trackStart)
        line = moveIArrayDown(line, trackStart, trackEnd - trackStart)
        tracksep = moveArrayDown(tracksep, trackID)
        tracks = moveSArrayDown(tracks, trackID)
        comboTrack.Items.RemoveAt(trackID)
    End Sub 'Removes track, but combines all tracks after it

    Private Sub cboxAntiAlias_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboxAntiAlias.CheckedChanged
        If (cboxAntiAlias.Checked = True) Then
            trackGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        Else
            trackGraphics.SmoothingMode = Drawing2D.SmoothingMode.HighSpeed
        End If
        drawTrack()
    End Sub
End Class