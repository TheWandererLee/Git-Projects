Public Class formNetwork
    Dim uploadTrack As String = ""
    Dim root As String = "http://www.13willows.com/lrtools/"
    Dim trackNum As String = ""

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub formNetwork_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        formMain.Visible = True
    End Sub

    Private Sub webNetwork_DocumentCompleted(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles webNetwork.DocumentCompleted
        If (webNetwork.Url.AbsolutePath = "/lrtools/track.php") Then
            btnDownload.Visible = True
        Else
            btnDownload.Visible = False
        End If
        If (webNetwork.DocumentText.Contains("Logged in as") = True) Then
            btnPublish.Visible = True
        Else
            btnPublish.Visible = False
        End If

        If (webNetwork.Url.AbsolutePath = "/lrtools/index.php") Then webNetwork.Refresh()

        If (webNetwork.Url.AbsolutePath.Contains("/lrtools/download.php")) Then
            trackNum = Mid(webNetwork.Url.AbsoluteUri, webNetwork.Url.AbsoluteUri.LastIndexOf("=") + 2)
            webNetwork.Navigate(root & "track.php?id=" & trackNum)

            saveFileNetwork.FileName = formMain.trackPath & "\" & webNetwork.DocumentTitle
            If (saveFileNetwork.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                If (My.Computer.FileSystem.FileExists(saveFileNetwork.FileName) = True) Then
                    My.Computer.FileSystem.DeleteFile(saveFileNetwork.FileName)
                End If
                Dim p As String = root & "tracks/" & trackNum & ".sol"
                Dim fl As String = saveFileNetwork.FileName
                My.Computer.Network.DownloadFile(root & "tracks/" & trackNum & ".sol", saveFileNetwork.FileName)
                MsgBox("Successfully downloaded " & webNetwork.DocumentTitle & "!", MsgBoxStyle.OkOnly, "Download Successfull")
            End If
        End If
    End Sub

    Private Sub btnPublish_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPublish.Click
        If (My.Computer.FileSystem.GetFiles(formMain.trackPath).Count = 1) Then
            For Each track As String In My.Computer.FileSystem.GetFiles(formMain.trackPath)
                uploadTrack = track
                webUpload.Navigate(root & "lastid.txt")
                Exit For
            Next
        ElseIf (My.Computer.FileSystem.GetFiles(formMain.trackPath).Count > 1) Then
            listTracks.Items.Clear()
            For Each track As String In My.Computer.FileSystem.GetFiles(formMain.trackPath)
                listTracks.Items.Add(Mid(track, track.LastIndexOf("\") + 2))
            Next
            grpPublish.Visible = True
        Else
            MsgBox("Cannot publish track, there are no tracks in this directory.", MsgBoxStyle.Exclamation, "Cannot Publish Track")
        End If
    End Sub

    Private Sub webUpload_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles webUpload.DocumentCompleted
        If (My.Computer.FileSystem.FileExists(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\tmpid.txt") = True) Then
            My.Computer.FileSystem.DeleteFile(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\tmpid.txt")
        End If
        Dim trackID As String = Mid(webUpload.DocumentText, webUpload.DocumentText.IndexOf("<PRE>") + 6, webUpload.DocumentText.IndexOf("</PRE>") - webUpload.DocumentText.IndexOf("<PRE>") - 5)
        'My.Computer.Network.DownloadFile(root & "lastid.txt", System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\tmpid.txt")
        'Dim trackID As String = My.Computer.FileSystem.ReadAllText(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\tmpid.txt")
        Try
            My.Computer.Network.UploadFile(uploadTrack, "ftp://www.13willows.com/tracks/" & trackID & ".sol", "lrtools", "sl00tRL")
        Catch exc As Exception
            MsgBox("Error: Unable to upload your track, please try again later." & vbCrLf & exc.Message, MsgBoxStyle.Exclamation, "Error: Unable to Upload Track")
            Exit Sub
        End Try
        My.Computer.FileSystem.WriteAllText(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\tmpid.txt", CStr(CInt(trackID) + 1), False)
        My.Computer.Network.UploadFile(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\tmpid.txt", "ftp://www.13willows.com/lastid.txt", "lrtools", "sl00tRL")
        My.Computer.FileSystem.DeleteFile(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\tmpid.txt")
        webNetwork.Navigate(root & "publish.php?id=" & trackID & "&name=" & txtName.Text & "&desc=" & txtDescription.Text)
        grpPublish.Visible = False
    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        webNetwork.Navigate(root & "index.php")
    End Sub

    Private Sub btnDownload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDownload.Click
        trackNum = Mid(webNetwork.Url.AbsoluteUri, webNetwork.Url.AbsoluteUri.LastIndexOf("=") + 2)
        webNetwork.Navigate(root & "download.php?id=" & trackNum)
    End Sub

    Private Sub btnPublishNow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPublishNow.Click
        If (listTracks.SelectedIndex <> -1) Then
            uploadTrack = formMain.trackPath & "\" & listTracks.SelectedItem
            webUpload.Navigate(root & "lastid.txt")
        End If
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        webNetwork.Refresh()
    End Sub

    Private Sub formNetwork_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim major As Integer = My.Application.Info.Version.Major
        Dim minor As Integer = My.Application.Info.Version.Minor
        Dim build As Integer = My.Application.Info.Version.Revision
        Dim revision As Integer = My.Application.Info.Version.Revision
        Dim version As Integer = major * 1000 + minor * 100 + build * 10 + revision
        webNetwork.Navigate(root & "index.php?v=" & version)
    End Sub
End Class