<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class formMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formMain))
        Me.statusMain = New System.Windows.Forms.StatusStrip
        Me.statusLblStatus = New System.Windows.Forms.ToolStripStatusLabel
        Me.statusLblMapFilePath = New System.Windows.Forms.ToolStripStatusLabel
        Me.statusLblSeparator = New System.Windows.Forms.ToolStripStatusLabel
        Me.statusLblMapName = New System.Windows.Forms.ToolStripStatusLabel
        Me.openMap = New System.Windows.Forms.OpenFileDialog
        Me.menuMain = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnOpen = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnSave = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnClose = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnExit = New System.Windows.Forms.ToolStripMenuItem
        Me.MapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnPluginConverter = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnManagePlugins = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnViewPlugin = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnHelpAbout = New System.Windows.Forms.ToolStripMenuItem
        Me.menuBtnDebug = New System.Windows.Forms.ToolStripMenuItem
        Me.lblOffset3 = New System.Windows.Forms.Label
        Me.txtOffset1 = New System.Windows.Forms.TextBox
        Me.lblOffset2 = New System.Windows.Forms.Label
        Me.txtOffset2 = New System.Windows.Forms.TextBox
        Me.lblOffset4 = New System.Windows.Forms.Label
        Me.txtOffset3 = New System.Windows.Forms.TextBox
        Me.lblOffset1 = New System.Windows.Forms.Label
        Me.txtOffset4 = New System.Windows.Forms.TextBox
        Me.lblOffset5 = New System.Windows.Forms.Label
        Me.txtOffset5 = New System.Windows.Forms.TextBox
        Me.lblOffset0 = New System.Windows.Forms.Label
        Me.txtOffset0 = New System.Windows.Forms.TextBox
        Me.txtOffset6 = New System.Windows.Forms.TextBox
        Me.lblOffset6 = New System.Windows.Forms.Label
        Me.lblOffset7 = New System.Windows.Forms.Label
        Me.txtOffset8 = New System.Windows.Forms.TextBox
        Me.txtOffset7 = New System.Windows.Forms.TextBox
        Me.txtOffset9 = New System.Windows.Forms.TextBox
        Me.txtOffset10 = New System.Windows.Forms.TextBox
        Me.lblOffset8 = New System.Windows.Forms.Label
        Me.lblOffset9 = New System.Windows.Forms.Label
        Me.lblOffset10 = New System.Windows.Forms.Label
        Me.txtOffset11 = New System.Windows.Forms.TextBox
        Me.txtOffset12 = New System.Windows.Forms.TextBox
        Me.txtOffset13 = New System.Windows.Forms.TextBox
        Me.txtOffset14 = New System.Windows.Forms.TextBox
        Me.txtOffset15 = New System.Windows.Forms.TextBox
        Me.txtOffset16 = New System.Windows.Forms.TextBox
        Me.txtOffset17 = New System.Windows.Forms.TextBox
        Me.txtOffset18 = New System.Windows.Forms.TextBox
        Me.txtOffset19 = New System.Windows.Forms.TextBox
        Me.lblOffset11 = New System.Windows.Forms.Label
        Me.lblOffset12 = New System.Windows.Forms.Label
        Me.lblOffset16 = New System.Windows.Forms.Label
        Me.lblOffset13 = New System.Windows.Forms.Label
        Me.lblOffset14 = New System.Windows.Forms.Label
        Me.lblOffset15 = New System.Windows.Forms.Label
        Me.lblOffset17 = New System.Windows.Forms.Label
        Me.lblOffset18 = New System.Windows.Forms.Label
        Me.lblOffset19 = New System.Windows.Forms.Label
        Me.vsbMain = New System.Windows.Forms.VScrollBar
        Me.pnlMain = New System.Windows.Forms.Panel
        Me.txtOffset50 = New System.Windows.Forms.TextBox
        Me.txtOffset40 = New System.Windows.Forms.TextBox
        Me.txtOffset49 = New System.Windows.Forms.TextBox
        Me.txtOffset51 = New System.Windows.Forms.TextBox
        Me.txtOffset47 = New System.Windows.Forms.TextBox
        Me.txtOffset52 = New System.Windows.Forms.TextBox
        Me.txtOffset48 = New System.Windows.Forms.TextBox
        Me.txtOffset43 = New System.Windows.Forms.TextBox
        Me.txtOffset53 = New System.Windows.Forms.TextBox
        Me.txtOffset42 = New System.Windows.Forms.TextBox
        Me.txtOffset54 = New System.Windows.Forms.TextBox
        Me.txtOffset41 = New System.Windows.Forms.TextBox
        Me.txtOffset55 = New System.Windows.Forms.TextBox
        Me.txtOffset46 = New System.Windows.Forms.TextBox
        Me.txtOffset56 = New System.Windows.Forms.TextBox
        Me.txtOffset45 = New System.Windows.Forms.TextBox
        Me.txtOffset57 = New System.Windows.Forms.TextBox
        Me.txtOffset58 = New System.Windows.Forms.TextBox
        Me.txtOffset44 = New System.Windows.Forms.TextBox
        Me.txtOffset59 = New System.Windows.Forms.TextBox
        Me.lblOffset59 = New System.Windows.Forms.Label
        Me.lblOffset58 = New System.Windows.Forms.Label
        Me.lblOffset57 = New System.Windows.Forms.Label
        Me.lblOffset56 = New System.Windows.Forms.Label
        Me.lblOffset55 = New System.Windows.Forms.Label
        Me.lblOffset48 = New System.Windows.Forms.Label
        Me.lblOffset49 = New System.Windows.Forms.Label
        Me.lblOffset50 = New System.Windows.Forms.Label
        Me.lblOffset47 = New System.Windows.Forms.Label
        Me.lblOffset46 = New System.Windows.Forms.Label
        Me.lblOffset54 = New System.Windows.Forms.Label
        Me.lblOffset53 = New System.Windows.Forms.Label
        Me.lblOffset52 = New System.Windows.Forms.Label
        Me.lblOffset51 = New System.Windows.Forms.Label
        Me.lblOffset45 = New System.Windows.Forms.Label
        Me.lblOffset44 = New System.Windows.Forms.Label
        Me.lblOffset43 = New System.Windows.Forms.Label
        Me.lblOffset42 = New System.Windows.Forms.Label
        Me.lblOffset40 = New System.Windows.Forms.Label
        Me.lblOffset41 = New System.Windows.Forms.Label
        Me.txtOffset30 = New System.Windows.Forms.TextBox
        Me.txtOffset20 = New System.Windows.Forms.TextBox
        Me.txtOffset29 = New System.Windows.Forms.TextBox
        Me.txtOffset31 = New System.Windows.Forms.TextBox
        Me.txtOffset27 = New System.Windows.Forms.TextBox
        Me.txtOffset32 = New System.Windows.Forms.TextBox
        Me.txtOffset28 = New System.Windows.Forms.TextBox
        Me.txtOffset23 = New System.Windows.Forms.TextBox
        Me.txtOffset33 = New System.Windows.Forms.TextBox
        Me.txtOffset22 = New System.Windows.Forms.TextBox
        Me.txtOffset34 = New System.Windows.Forms.TextBox
        Me.txtOffset21 = New System.Windows.Forms.TextBox
        Me.txtOffset35 = New System.Windows.Forms.TextBox
        Me.txtOffset26 = New System.Windows.Forms.TextBox
        Me.txtOffset36 = New System.Windows.Forms.TextBox
        Me.txtOffset25 = New System.Windows.Forms.TextBox
        Me.txtOffset37 = New System.Windows.Forms.TextBox
        Me.txtOffset38 = New System.Windows.Forms.TextBox
        Me.txtOffset24 = New System.Windows.Forms.TextBox
        Me.txtOffset39 = New System.Windows.Forms.TextBox
        Me.lblOffset39 = New System.Windows.Forms.Label
        Me.lblOffset38 = New System.Windows.Forms.Label
        Me.lblOffset37 = New System.Windows.Forms.Label
        Me.lblOffset36 = New System.Windows.Forms.Label
        Me.lblOffset35 = New System.Windows.Forms.Label
        Me.lblOffset28 = New System.Windows.Forms.Label
        Me.lblOffset29 = New System.Windows.Forms.Label
        Me.lblOffset30 = New System.Windows.Forms.Label
        Me.lblOffset27 = New System.Windows.Forms.Label
        Me.lblOffset26 = New System.Windows.Forms.Label
        Me.lblOffset34 = New System.Windows.Forms.Label
        Me.lblOffset33 = New System.Windows.Forms.Label
        Me.lblOffset32 = New System.Windows.Forms.Label
        Me.lblOffset31 = New System.Windows.Forms.Label
        Me.lblOffset25 = New System.Windows.Forms.Label
        Me.lblOffset24 = New System.Windows.Forms.Label
        Me.lblOffset23 = New System.Windows.Forms.Label
        Me.lblOffset22 = New System.Windows.Forms.Label
        Me.lblOffset20 = New System.Windows.Forms.Label
        Me.lblOffset21 = New System.Windows.Forms.Label
        Me.picInitialPicture = New System.Windows.Forms.PictureBox
        Me.progLoading = New System.Windows.Forms.ProgressBar
        Me.statusMain.SuspendLayout()
        Me.menuMain.SuspendLayout()
        Me.pnlMain.SuspendLayout()
        CType(Me.picInitialPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'statusMain
        '
        Me.statusMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statusLblStatus, Me.statusLblMapFilePath, Me.statusLblSeparator, Me.statusLblMapName})
        Me.statusMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table
        Me.statusMain.Location = New System.Drawing.Point(0, 499)
        Me.statusMain.Name = "statusMain"
        Me.statusMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.statusMain.Size = New System.Drawing.Size(605, 23)
        Me.statusMain.TabIndex = 6
        Me.statusMain.Text = "statusMain"
        '
        'statusLblStatus
        '
        Me.statusLblStatus.Name = "statusLblStatus"
        Me.statusLblStatus.Text = "Status:"
        '
        'statusLblMapFilePath
        '
        Me.statusLblMapFilePath.Name = "statusLblMapFilePath"
        Me.statusLblMapFilePath.Text = "Map File Path"
        '
        'statusLblSeparator
        '
        Me.statusLblSeparator.Name = "statusLblSeparator"
        Me.statusLblSeparator.Text = "-"
        '
        'statusLblMapName
        '
        Me.statusLblMapName.Name = "statusLblMapName"
        Me.statusLblMapName.Text = "Map Name"
        '
        'openMap
        '
        Me.openMap.DefaultExt = "map"
        Me.openMap.Filter = "Halo 2 Map Files (.map)|*.map"
        Me.openMap.Title = "Open map..."
        '
        'menuMain
        '
        Me.menuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.MapToolStripMenuItem, Me.menuBtnHelp})
        Me.menuMain.Location = New System.Drawing.Point(0, 0)
        Me.menuMain.Name = "menuMain"
        Me.menuMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.menuMain.Size = New System.Drawing.Size(605, 24)
        Me.menuMain.TabIndex = 19
        Me.menuMain.Text = "Main Menu"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnOpen, Me.menuBtnSave, Me.menuBtnClose, Me.menuBtnExit})
        Me.FileToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Text = "File"
        '
        'menuBtnOpen
        '
        Me.menuBtnOpen.Image = H_Name.My.Resources.Resources.Icon_159
        Me.menuBtnOpen.ImageTransparentColor = System.Drawing.Color.White
        Me.menuBtnOpen.Name = "menuBtnOpen"
        Me.menuBtnOpen.Text = "Open Map..."
        '
        'menuBtnSave
        '
        Me.menuBtnSave.Image = H_Name.My.Resources.Resources.Icon_148
        Me.menuBtnSave.ImageTransparentColor = System.Drawing.Color.White
        Me.menuBtnSave.Name = "menuBtnSave"
        Me.menuBtnSave.Text = "Save Map..."
        '
        'menuBtnClose
        '
        Me.menuBtnClose.Image = H_Name.My.Resources.Resources.Icon_156
        Me.menuBtnClose.ImageTransparentColor = System.Drawing.Color.White
        Me.menuBtnClose.Name = "menuBtnClose"
        Me.menuBtnClose.Text = "Close Map"
        '
        'menuBtnExit
        '
        Me.menuBtnExit.Image = H_Name.My.Resources.Resources.Icon_28
        Me.menuBtnExit.ImageTransparentColor = System.Drawing.Color.White
        Me.menuBtnExit.Name = "menuBtnExit"
        Me.menuBtnExit.Text = "Exit"
        '
        'MapToolStripMenuItem
        '
        Me.MapToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnPluginConverter, Me.menuBtnManagePlugins, Me.menuBtnViewPlugin})
        Me.MapToolStripMenuItem.Name = "MapToolStripMenuItem"
        Me.MapToolStripMenuItem.Text = "Plugin"
        '
        'menuBtnPluginConverter
        '
        Me.menuBtnPluginConverter.Image = H_Name.My.Resources.Resources.Icon_81
        Me.menuBtnPluginConverter.Name = "menuBtnPluginConverter"
        Me.menuBtnPluginConverter.Text = "Plugin Converter"
        '
        'menuBtnManagePlugins
        '
        Me.menuBtnManagePlugins.Image = H_Name.My.Resources.Resources.Icon_22
        Me.menuBtnManagePlugins.ImageTransparentColor = System.Drawing.Color.White
        Me.menuBtnManagePlugins.Name = "menuBtnManagePlugins"
        Me.menuBtnManagePlugins.Text = "Manage Plugins"
        '
        'menuBtnViewPlugin
        '
        Me.menuBtnViewPlugin.Image = H_Name.My.Resources.Resources.Icon_134
        Me.menuBtnViewPlugin.ImageTransparentColor = System.Drawing.Color.White
        Me.menuBtnViewPlugin.Name = "menuBtnViewPlugin"
        Me.menuBtnViewPlugin.Text = "Edit Plugin Source"
        '
        'menuBtnHelp
        '
        Me.menuBtnHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuBtnHelpAbout, Me.menuBtnDebug})
        Me.menuBtnHelp.Name = "menuBtnHelp"
        Me.menuBtnHelp.Text = "Help"
        '
        'menuBtnHelpAbout
        '
        Me.menuBtnHelpAbout.Image = H_Name.My.Resources.Resources.Icon_1
        Me.menuBtnHelpAbout.ImageTransparentColor = System.Drawing.Color.Black
        Me.menuBtnHelpAbout.Name = "menuBtnHelpAbout"
        Me.menuBtnHelpAbout.Text = "About"
        '
        'menuBtnDebug
        '
        Me.menuBtnDebug.Image = H_Name.My.Resources.Resources.Icon_211
        Me.menuBtnDebug.ImageTransparentColor = System.Drawing.Color.White
        Me.menuBtnDebug.Name = "menuBtnDebug"
        Me.menuBtnDebug.Text = "Debug Information"
        '
        'lblOffset3
        '
        Me.lblOffset3.AutoSize = True
        Me.lblOffset3.Location = New System.Drawing.Point(512, 54)
        Me.lblOffset3.Name = "lblOffset3"
        Me.lblOffset3.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset3.TabIndex = 11
        Me.lblOffset3.Text = "                              "
        '
        'txtOffset1
        '
        Me.txtOffset1.Location = New System.Drawing.Point(159, 50)
        Me.txtOffset1.Name = "txtOffset1"
        Me.txtOffset1.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset1.TabIndex = 2
        Me.txtOffset1.Visible = False
        '
        'lblOffset2
        '
        Me.lblOffset2.AutoSize = True
        Me.lblOffset2.Location = New System.Drawing.Point(365, 54)
        Me.lblOffset2.Name = "lblOffset2"
        Me.lblOffset2.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset2.TabIndex = 10
        Me.lblOffset2.Text = "                              "
        '
        'txtOffset2
        '
        Me.txtOffset2.Location = New System.Drawing.Point(306, 51)
        Me.txtOffset2.Name = "txtOffset2"
        Me.txtOffset2.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset2.TabIndex = 3
        Me.txtOffset2.Visible = False
        '
        'lblOffset4
        '
        Me.lblOffset4.AutoSize = True
        Me.lblOffset4.Location = New System.Drawing.Point(71, 80)
        Me.lblOffset4.Name = "lblOffset4"
        Me.lblOffset4.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset4.TabIndex = 12
        Me.lblOffset4.Text = "                              "
        '
        'txtOffset3
        '
        Me.txtOffset3.Location = New System.Drawing.Point(453, 51)
        Me.txtOffset3.Name = "txtOffset3"
        Me.txtOffset3.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset3.TabIndex = 4
        Me.txtOffset3.Visible = False
        '
        'lblOffset1
        '
        Me.lblOffset1.AutoSize = True
        Me.lblOffset1.Location = New System.Drawing.Point(218, 53)
        Me.lblOffset1.Name = "lblOffset1"
        Me.lblOffset1.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset1.TabIndex = 10
        Me.lblOffset1.Text = "                              "
        '
        'txtOffset4
        '
        Me.txtOffset4.Location = New System.Drawing.Point(12, 77)
        Me.txtOffset4.Name = "txtOffset4"
        Me.txtOffset4.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset4.TabIndex = 5
        Me.txtOffset4.Visible = False
        '
        'lblOffset5
        '
        Me.lblOffset5.AutoSize = True
        Me.lblOffset5.Location = New System.Drawing.Point(219, 80)
        Me.lblOffset5.Name = "lblOffset5"
        Me.lblOffset5.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset5.TabIndex = 13
        Me.lblOffset5.Text = "                              "
        '
        'txtOffset5
        '
        Me.txtOffset5.Location = New System.Drawing.Point(159, 77)
        Me.txtOffset5.Name = "txtOffset5"
        Me.txtOffset5.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset5.TabIndex = 6
        Me.txtOffset5.Visible = False
        '
        'lblOffset0
        '
        Me.lblOffset0.AutoSize = True
        Me.lblOffset0.Location = New System.Drawing.Point(71, 54)
        Me.lblOffset0.Name = "lblOffset0"
        Me.lblOffset0.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset0.TabIndex = 15
        Me.lblOffset0.Text = "                              "
        '
        'txtOffset0
        '
        Me.txtOffset0.Location = New System.Drawing.Point(12, 51)
        Me.txtOffset0.Name = "txtOffset0"
        Me.txtOffset0.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset0.TabIndex = 1
        Me.txtOffset0.Visible = False
        '
        'txtOffset6
        '
        Me.txtOffset6.Location = New System.Drawing.Point(306, 77)
        Me.txtOffset6.Name = "txtOffset6"
        Me.txtOffset6.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset6.TabIndex = 7
        Me.txtOffset6.Visible = False
        '
        'lblOffset6
        '
        Me.lblOffset6.AutoSize = True
        Me.lblOffset6.Location = New System.Drawing.Point(366, 80)
        Me.lblOffset6.Name = "lblOffset6"
        Me.lblOffset6.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset6.TabIndex = 12
        Me.lblOffset6.Text = "                              "
        '
        'lblOffset7
        '
        Me.lblOffset7.AutoSize = True
        Me.lblOffset7.Location = New System.Drawing.Point(513, 80)
        Me.lblOffset7.Name = "lblOffset7"
        Me.lblOffset7.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset7.TabIndex = 12
        Me.lblOffset7.Text = "                              "
        '
        'txtOffset8
        '
        Me.txtOffset8.Location = New System.Drawing.Point(12, 103)
        Me.txtOffset8.Name = "txtOffset8"
        Me.txtOffset8.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset8.TabIndex = 9
        Me.txtOffset8.Visible = False
        '
        'txtOffset7
        '
        Me.txtOffset7.Location = New System.Drawing.Point(453, 77)
        Me.txtOffset7.Name = "txtOffset7"
        Me.txtOffset7.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset7.TabIndex = 8
        Me.txtOffset7.Visible = False
        '
        'txtOffset9
        '
        Me.txtOffset9.Location = New System.Drawing.Point(159, 103)
        Me.txtOffset9.Name = "txtOffset9"
        Me.txtOffset9.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset9.TabIndex = 10
        Me.txtOffset9.Visible = False
        '
        'txtOffset10
        '
        Me.txtOffset10.Location = New System.Drawing.Point(307, 103)
        Me.txtOffset10.Name = "txtOffset10"
        Me.txtOffset10.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset10.TabIndex = 11
        Me.txtOffset10.Visible = False
        '
        'lblOffset8
        '
        Me.lblOffset8.AutoSize = True
        Me.lblOffset8.Location = New System.Drawing.Point(72, 106)
        Me.lblOffset8.Name = "lblOffset8"
        Me.lblOffset8.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset8.TabIndex = 12
        Me.lblOffset8.Text = "                              "
        '
        'lblOffset9
        '
        Me.lblOffset9.AutoSize = True
        Me.lblOffset9.Location = New System.Drawing.Point(218, 106)
        Me.lblOffset9.Name = "lblOffset9"
        Me.lblOffset9.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset9.TabIndex = 16
        Me.lblOffset9.Text = "                              "
        '
        'lblOffset10
        '
        Me.lblOffset10.AutoSize = True
        Me.lblOffset10.Location = New System.Drawing.Point(365, 106)
        Me.lblOffset10.Name = "lblOffset10"
        Me.lblOffset10.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset10.TabIndex = 17
        Me.lblOffset10.Text = "                              "
        '
        'txtOffset11
        '
        Me.txtOffset11.Location = New System.Drawing.Point(453, 103)
        Me.txtOffset11.Name = "txtOffset11"
        Me.txtOffset11.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset11.TabIndex = 18
        Me.txtOffset11.Visible = False
        '
        'txtOffset12
        '
        Me.txtOffset12.Location = New System.Drawing.Point(12, 129)
        Me.txtOffset12.Name = "txtOffset12"
        Me.txtOffset12.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset12.TabIndex = 19
        Me.txtOffset12.Visible = False
        '
        'txtOffset13
        '
        Me.txtOffset13.Location = New System.Drawing.Point(158, 132)
        Me.txtOffset13.Name = "txtOffset13"
        Me.txtOffset13.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset13.TabIndex = 20
        Me.txtOffset13.Visible = False
        '
        'txtOffset14
        '
        Me.txtOffset14.Location = New System.Drawing.Point(306, 129)
        Me.txtOffset14.Name = "txtOffset14"
        Me.txtOffset14.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset14.TabIndex = 21
        Me.txtOffset14.Visible = False
        '
        'txtOffset15
        '
        Me.txtOffset15.Location = New System.Drawing.Point(453, 129)
        Me.txtOffset15.Name = "txtOffset15"
        Me.txtOffset15.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset15.TabIndex = 22
        Me.txtOffset15.Visible = False
        '
        'txtOffset16
        '
        Me.txtOffset16.Location = New System.Drawing.Point(12, 155)
        Me.txtOffset16.Name = "txtOffset16"
        Me.txtOffset16.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset16.TabIndex = 23
        Me.txtOffset16.Visible = False
        '
        'txtOffset17
        '
        Me.txtOffset17.Location = New System.Drawing.Point(158, 155)
        Me.txtOffset17.Name = "txtOffset17"
        Me.txtOffset17.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset17.TabIndex = 24
        Me.txtOffset17.Visible = False
        '
        'txtOffset18
        '
        Me.txtOffset18.Location = New System.Drawing.Point(305, 155)
        Me.txtOffset18.Name = "txtOffset18"
        Me.txtOffset18.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset18.TabIndex = 25
        Me.txtOffset18.Visible = False
        '
        'txtOffset19
        '
        Me.txtOffset19.Location = New System.Drawing.Point(452, 155)
        Me.txtOffset19.Name = "txtOffset19"
        Me.txtOffset19.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset19.TabIndex = 26
        Me.txtOffset19.Visible = False
        '
        'lblOffset11
        '
        Me.lblOffset11.AutoSize = True
        Me.lblOffset11.Location = New System.Drawing.Point(512, 106)
        Me.lblOffset11.Name = "lblOffset11"
        Me.lblOffset11.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset11.TabIndex = 27
        Me.lblOffset11.Text = "                              "
        '
        'lblOffset12
        '
        Me.lblOffset12.AutoSize = True
        Me.lblOffset12.Location = New System.Drawing.Point(71, 132)
        Me.lblOffset12.Name = "lblOffset12"
        Me.lblOffset12.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset12.TabIndex = 28
        Me.lblOffset12.Text = "                              "
        '
        'lblOffset16
        '
        Me.lblOffset16.AutoSize = True
        Me.lblOffset16.Location = New System.Drawing.Point(71, 158)
        Me.lblOffset16.Name = "lblOffset16"
        Me.lblOffset16.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset16.TabIndex = 29
        Me.lblOffset16.Text = "                              "
        '
        'lblOffset13
        '
        Me.lblOffset13.AutoSize = True
        Me.lblOffset13.Location = New System.Drawing.Point(219, 132)
        Me.lblOffset13.Name = "lblOffset13"
        Me.lblOffset13.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset13.TabIndex = 30
        Me.lblOffset13.Text = "                              "
        '
        'lblOffset14
        '
        Me.lblOffset14.AutoSize = True
        Me.lblOffset14.Location = New System.Drawing.Point(367, 132)
        Me.lblOffset14.Name = "lblOffset14"
        Me.lblOffset14.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset14.TabIndex = 31
        Me.lblOffset14.Text = "                              "
        '
        'lblOffset15
        '
        Me.lblOffset15.AutoSize = True
        Me.lblOffset15.Location = New System.Drawing.Point(513, 132)
        Me.lblOffset15.Name = "lblOffset15"
        Me.lblOffset15.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset15.TabIndex = 32
        Me.lblOffset15.Text = "                              "
        '
        'lblOffset17
        '
        Me.lblOffset17.AutoSize = True
        Me.lblOffset17.Location = New System.Drawing.Point(217, 158)
        Me.lblOffset17.Name = "lblOffset17"
        Me.lblOffset17.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset17.TabIndex = 33
        Me.lblOffset17.Text = "                              "
        '
        'lblOffset18
        '
        Me.lblOffset18.AutoSize = True
        Me.lblOffset18.Location = New System.Drawing.Point(364, 158)
        Me.lblOffset18.Name = "lblOffset18"
        Me.lblOffset18.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset18.TabIndex = 34
        Me.lblOffset18.Text = "                              "
        '
        'lblOffset19
        '
        Me.lblOffset19.AutoSize = True
        Me.lblOffset19.Location = New System.Drawing.Point(511, 158)
        Me.lblOffset19.Name = "lblOffset19"
        Me.lblOffset19.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset19.TabIndex = 35
        Me.lblOffset19.Text = "                              "
        '
        'vsbMain
        '
        Me.vsbMain.LargeChange = 20
        Me.vsbMain.Location = New System.Drawing.Point(385, 24)
        Me.vsbMain.Maximum = 1800
        Me.vsbMain.Name = "vsbMain"
        Me.vsbMain.Size = New System.Drawing.Size(17, 333)
        Me.vsbMain.SmallChange = 5
        Me.vsbMain.TabIndex = 36
        '
        'pnlMain
        '
        Me.pnlMain.Controls.Add(Me.txtOffset50)
        Me.pnlMain.Controls.Add(Me.txtOffset40)
        Me.pnlMain.Controls.Add(Me.txtOffset49)
        Me.pnlMain.Controls.Add(Me.txtOffset51)
        Me.pnlMain.Controls.Add(Me.txtOffset47)
        Me.pnlMain.Controls.Add(Me.txtOffset52)
        Me.pnlMain.Controls.Add(Me.txtOffset48)
        Me.pnlMain.Controls.Add(Me.txtOffset43)
        Me.pnlMain.Controls.Add(Me.txtOffset53)
        Me.pnlMain.Controls.Add(Me.txtOffset42)
        Me.pnlMain.Controls.Add(Me.txtOffset54)
        Me.pnlMain.Controls.Add(Me.txtOffset41)
        Me.pnlMain.Controls.Add(Me.txtOffset55)
        Me.pnlMain.Controls.Add(Me.txtOffset46)
        Me.pnlMain.Controls.Add(Me.txtOffset56)
        Me.pnlMain.Controls.Add(Me.txtOffset45)
        Me.pnlMain.Controls.Add(Me.txtOffset57)
        Me.pnlMain.Controls.Add(Me.txtOffset58)
        Me.pnlMain.Controls.Add(Me.txtOffset44)
        Me.pnlMain.Controls.Add(Me.txtOffset59)
        Me.pnlMain.Controls.Add(Me.lblOffset59)
        Me.pnlMain.Controls.Add(Me.lblOffset58)
        Me.pnlMain.Controls.Add(Me.lblOffset57)
        Me.pnlMain.Controls.Add(Me.lblOffset56)
        Me.pnlMain.Controls.Add(Me.lblOffset55)
        Me.pnlMain.Controls.Add(Me.lblOffset48)
        Me.pnlMain.Controls.Add(Me.lblOffset49)
        Me.pnlMain.Controls.Add(Me.lblOffset50)
        Me.pnlMain.Controls.Add(Me.lblOffset47)
        Me.pnlMain.Controls.Add(Me.lblOffset46)
        Me.pnlMain.Controls.Add(Me.lblOffset54)
        Me.pnlMain.Controls.Add(Me.lblOffset53)
        Me.pnlMain.Controls.Add(Me.lblOffset52)
        Me.pnlMain.Controls.Add(Me.lblOffset51)
        Me.pnlMain.Controls.Add(Me.lblOffset45)
        Me.pnlMain.Controls.Add(Me.lblOffset44)
        Me.pnlMain.Controls.Add(Me.lblOffset43)
        Me.pnlMain.Controls.Add(Me.lblOffset42)
        Me.pnlMain.Controls.Add(Me.lblOffset40)
        Me.pnlMain.Controls.Add(Me.lblOffset41)
        Me.pnlMain.Controls.Add(Me.txtOffset30)
        Me.pnlMain.Controls.Add(Me.txtOffset20)
        Me.pnlMain.Controls.Add(Me.txtOffset29)
        Me.pnlMain.Controls.Add(Me.txtOffset31)
        Me.pnlMain.Controls.Add(Me.txtOffset27)
        Me.pnlMain.Controls.Add(Me.txtOffset32)
        Me.pnlMain.Controls.Add(Me.txtOffset28)
        Me.pnlMain.Controls.Add(Me.txtOffset23)
        Me.pnlMain.Controls.Add(Me.txtOffset33)
        Me.pnlMain.Controls.Add(Me.txtOffset22)
        Me.pnlMain.Controls.Add(Me.txtOffset34)
        Me.pnlMain.Controls.Add(Me.txtOffset21)
        Me.pnlMain.Controls.Add(Me.txtOffset35)
        Me.pnlMain.Controls.Add(Me.txtOffset26)
        Me.pnlMain.Controls.Add(Me.txtOffset36)
        Me.pnlMain.Controls.Add(Me.txtOffset25)
        Me.pnlMain.Controls.Add(Me.txtOffset37)
        Me.pnlMain.Controls.Add(Me.txtOffset38)
        Me.pnlMain.Controls.Add(Me.txtOffset24)
        Me.pnlMain.Controls.Add(Me.txtOffset39)
        Me.pnlMain.Controls.Add(Me.txtOffset10)
        Me.pnlMain.Controls.Add(Me.txtOffset0)
        Me.pnlMain.Controls.Add(Me.txtOffset9)
        Me.pnlMain.Controls.Add(Me.txtOffset11)
        Me.pnlMain.Controls.Add(Me.txtOffset7)
        Me.pnlMain.Controls.Add(Me.txtOffset12)
        Me.pnlMain.Controls.Add(Me.txtOffset8)
        Me.pnlMain.Controls.Add(Me.txtOffset3)
        Me.pnlMain.Controls.Add(Me.txtOffset13)
        Me.pnlMain.Controls.Add(Me.txtOffset2)
        Me.pnlMain.Controls.Add(Me.txtOffset14)
        Me.pnlMain.Controls.Add(Me.txtOffset1)
        Me.pnlMain.Controls.Add(Me.txtOffset15)
        Me.pnlMain.Controls.Add(Me.txtOffset6)
        Me.pnlMain.Controls.Add(Me.txtOffset16)
        Me.pnlMain.Controls.Add(Me.txtOffset5)
        Me.pnlMain.Controls.Add(Me.txtOffset17)
        Me.pnlMain.Controls.Add(Me.txtOffset18)
        Me.pnlMain.Controls.Add(Me.txtOffset4)
        Me.pnlMain.Controls.Add(Me.txtOffset19)
        Me.pnlMain.Controls.Add(Me.lblOffset39)
        Me.pnlMain.Controls.Add(Me.lblOffset38)
        Me.pnlMain.Controls.Add(Me.lblOffset37)
        Me.pnlMain.Controls.Add(Me.lblOffset36)
        Me.pnlMain.Controls.Add(Me.lblOffset35)
        Me.pnlMain.Controls.Add(Me.lblOffset28)
        Me.pnlMain.Controls.Add(Me.lblOffset29)
        Me.pnlMain.Controls.Add(Me.lblOffset30)
        Me.pnlMain.Controls.Add(Me.lblOffset27)
        Me.pnlMain.Controls.Add(Me.lblOffset26)
        Me.pnlMain.Controls.Add(Me.lblOffset34)
        Me.pnlMain.Controls.Add(Me.lblOffset33)
        Me.pnlMain.Controls.Add(Me.lblOffset32)
        Me.pnlMain.Controls.Add(Me.lblOffset31)
        Me.pnlMain.Controls.Add(Me.lblOffset25)
        Me.pnlMain.Controls.Add(Me.lblOffset24)
        Me.pnlMain.Controls.Add(Me.lblOffset23)
        Me.pnlMain.Controls.Add(Me.lblOffset22)
        Me.pnlMain.Controls.Add(Me.lblOffset20)
        Me.pnlMain.Controls.Add(Me.lblOffset21)
        Me.pnlMain.Controls.Add(Me.lblOffset19)
        Me.pnlMain.Controls.Add(Me.lblOffset18)
        Me.pnlMain.Controls.Add(Me.lblOffset17)
        Me.pnlMain.Controls.Add(Me.lblOffset16)
        Me.pnlMain.Controls.Add(Me.lblOffset15)
        Me.pnlMain.Controls.Add(Me.lblOffset8)
        Me.pnlMain.Controls.Add(Me.lblOffset9)
        Me.pnlMain.Controls.Add(Me.lblOffset10)
        Me.pnlMain.Controls.Add(Me.lblOffset7)
        Me.pnlMain.Controls.Add(Me.lblOffset6)
        Me.pnlMain.Controls.Add(Me.lblOffset14)
        Me.pnlMain.Controls.Add(Me.lblOffset13)
        Me.pnlMain.Controls.Add(Me.lblOffset12)
        Me.pnlMain.Controls.Add(Me.lblOffset11)
        Me.pnlMain.Controls.Add(Me.lblOffset5)
        Me.pnlMain.Controls.Add(Me.lblOffset4)
        Me.pnlMain.Controls.Add(Me.lblOffset3)
        Me.pnlMain.Controls.Add(Me.lblOffset2)
        Me.pnlMain.Controls.Add(Me.picInitialPicture)
        Me.pnlMain.Controls.Add(Me.lblOffset0)
        Me.pnlMain.Controls.Add(Me.lblOffset1)
        Me.pnlMain.Location = New System.Drawing.Point(0, 30)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(604, 467)
        Me.pnlMain.TabIndex = 37
        '
        'txtOffset50
        '
        Me.txtOffset50.Location = New System.Drawing.Point(307, 382)
        Me.txtOffset50.Name = "txtOffset50"
        Me.txtOffset50.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset50.TabIndex = 97
        Me.txtOffset50.Visible = False
        '
        'txtOffset40
        '
        Me.txtOffset40.Location = New System.Drawing.Point(12, 330)
        Me.txtOffset40.Name = "txtOffset40"
        Me.txtOffset40.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset40.TabIndex = 87
        Me.txtOffset40.Visible = False
        '
        'txtOffset49
        '
        Me.txtOffset49.Location = New System.Drawing.Point(160, 382)
        Me.txtOffset49.Name = "txtOffset49"
        Me.txtOffset49.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset49.TabIndex = 96
        Me.txtOffset49.Visible = False
        '
        'txtOffset51
        '
        Me.txtOffset51.Location = New System.Drawing.Point(453, 382)
        Me.txtOffset51.Name = "txtOffset51"
        Me.txtOffset51.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset51.TabIndex = 98
        Me.txtOffset51.Visible = False
        '
        'txtOffset47
        '
        Me.txtOffset47.Location = New System.Drawing.Point(453, 356)
        Me.txtOffset47.Name = "txtOffset47"
        Me.txtOffset47.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset47.TabIndex = 94
        Me.txtOffset47.Visible = False
        '
        'txtOffset52
        '
        Me.txtOffset52.Location = New System.Drawing.Point(12, 408)
        Me.txtOffset52.Name = "txtOffset52"
        Me.txtOffset52.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset52.TabIndex = 99
        Me.txtOffset52.Visible = False
        '
        'txtOffset48
        '
        Me.txtOffset48.Location = New System.Drawing.Point(12, 382)
        Me.txtOffset48.Name = "txtOffset48"
        Me.txtOffset48.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset48.TabIndex = 95
        Me.txtOffset48.Visible = False
        '
        'txtOffset43
        '
        Me.txtOffset43.Location = New System.Drawing.Point(453, 330)
        Me.txtOffset43.Name = "txtOffset43"
        Me.txtOffset43.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset43.TabIndex = 90
        Me.txtOffset43.Visible = False
        '
        'txtOffset53
        '
        Me.txtOffset53.Location = New System.Drawing.Point(160, 408)
        Me.txtOffset53.Name = "txtOffset53"
        Me.txtOffset53.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset53.TabIndex = 100
        Me.txtOffset53.Visible = False
        '
        'txtOffset42
        '
        Me.txtOffset42.Location = New System.Drawing.Point(306, 330)
        Me.txtOffset42.Name = "txtOffset42"
        Me.txtOffset42.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset42.TabIndex = 89
        Me.txtOffset42.Visible = False
        '
        'txtOffset54
        '
        Me.txtOffset54.Location = New System.Drawing.Point(306, 408)
        Me.txtOffset54.Name = "txtOffset54"
        Me.txtOffset54.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset54.TabIndex = 101
        Me.txtOffset54.Visible = False
        '
        'txtOffset41
        '
        Me.txtOffset41.Location = New System.Drawing.Point(159, 329)
        Me.txtOffset41.Name = "txtOffset41"
        Me.txtOffset41.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset41.TabIndex = 88
        Me.txtOffset41.Visible = False
        '
        'txtOffset55
        '
        Me.txtOffset55.Location = New System.Drawing.Point(453, 408)
        Me.txtOffset55.Name = "txtOffset55"
        Me.txtOffset55.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset55.TabIndex = 102
        Me.txtOffset55.Visible = False
        '
        'txtOffset46
        '
        Me.txtOffset46.Location = New System.Drawing.Point(306, 356)
        Me.txtOffset46.Name = "txtOffset46"
        Me.txtOffset46.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset46.TabIndex = 93
        Me.txtOffset46.Visible = False
        '
        'txtOffset56
        '
        Me.txtOffset56.Location = New System.Drawing.Point(12, 434)
        Me.txtOffset56.Name = "txtOffset56"
        Me.txtOffset56.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset56.TabIndex = 103
        Me.txtOffset56.Visible = False
        '
        'txtOffset45
        '
        Me.txtOffset45.Location = New System.Drawing.Point(159, 356)
        Me.txtOffset45.Name = "txtOffset45"
        Me.txtOffset45.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset45.TabIndex = 92
        Me.txtOffset45.Visible = False
        '
        'txtOffset57
        '
        Me.txtOffset57.Location = New System.Drawing.Point(158, 434)
        Me.txtOffset57.Name = "txtOffset57"
        Me.txtOffset57.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset57.TabIndex = 104
        Me.txtOffset57.Visible = False
        '
        'txtOffset58
        '
        Me.txtOffset58.Location = New System.Drawing.Point(305, 434)
        Me.txtOffset58.Name = "txtOffset58"
        Me.txtOffset58.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset58.TabIndex = 105
        Me.txtOffset58.Visible = False
        '
        'txtOffset44
        '
        Me.txtOffset44.Location = New System.Drawing.Point(12, 356)
        Me.txtOffset44.Name = "txtOffset44"
        Me.txtOffset44.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset44.TabIndex = 91
        Me.txtOffset44.Visible = False
        '
        'txtOffset59
        '
        Me.txtOffset59.Location = New System.Drawing.Point(452, 434)
        Me.txtOffset59.Name = "txtOffset59"
        Me.txtOffset59.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset59.TabIndex = 106
        Me.txtOffset59.Visible = False
        '
        'lblOffset59
        '
        Me.lblOffset59.AutoSize = True
        Me.lblOffset59.Location = New System.Drawing.Point(512, 437)
        Me.lblOffset59.Name = "lblOffset59"
        Me.lblOffset59.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset59.TabIndex = 115
        Me.lblOffset59.Text = "                              "
        '
        'lblOffset58
        '
        Me.lblOffset58.AutoSize = True
        Me.lblOffset58.Location = New System.Drawing.Point(364, 437)
        Me.lblOffset58.Name = "lblOffset58"
        Me.lblOffset58.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset58.TabIndex = 114
        Me.lblOffset58.Text = "                              "
        '
        'lblOffset57
        '
        Me.lblOffset57.AutoSize = True
        Me.lblOffset57.Location = New System.Drawing.Point(217, 437)
        Me.lblOffset57.Name = "lblOffset57"
        Me.lblOffset57.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset57.TabIndex = 113
        Me.lblOffset57.Text = "                              "
        '
        'lblOffset56
        '
        Me.lblOffset56.AutoSize = True
        Me.lblOffset56.Location = New System.Drawing.Point(71, 437)
        Me.lblOffset56.Name = "lblOffset56"
        Me.lblOffset56.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset56.TabIndex = 109
        Me.lblOffset56.Text = "                              "
        '
        'lblOffset55
        '
        Me.lblOffset55.AutoSize = True
        Me.lblOffset55.Location = New System.Drawing.Point(513, 411)
        Me.lblOffset55.Name = "lblOffset55"
        Me.lblOffset55.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset55.TabIndex = 112
        Me.lblOffset55.Text = "                              "
        '
        'lblOffset48
        '
        Me.lblOffset48.AutoSize = True
        Me.lblOffset48.Location = New System.Drawing.Point(72, 385)
        Me.lblOffset48.Name = "lblOffset48"
        Me.lblOffset48.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset48.TabIndex = 89
        Me.lblOffset48.Text = "                              "
        '
        'lblOffset49
        '
        Me.lblOffset49.AutoSize = True
        Me.lblOffset49.Location = New System.Drawing.Point(218, 385)
        Me.lblOffset49.Name = "lblOffset49"
        Me.lblOffset49.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset49.TabIndex = 96
        Me.lblOffset49.Text = "                              "
        '
        'lblOffset50
        '
        Me.lblOffset50.AutoSize = True
        Me.lblOffset50.Location = New System.Drawing.Point(365, 385)
        Me.lblOffset50.Name = "lblOffset50"
        Me.lblOffset50.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset50.TabIndex = 97
        Me.lblOffset50.Text = "                              "
        '
        'lblOffset47
        '
        Me.lblOffset47.AutoSize = True
        Me.lblOffset47.Location = New System.Drawing.Point(513, 359)
        Me.lblOffset47.Name = "lblOffset47"
        Me.lblOffset47.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset47.TabIndex = 88
        Me.lblOffset47.Text = "                              "
        '
        'lblOffset46
        '
        Me.lblOffset46.AutoSize = True
        Me.lblOffset46.Location = New System.Drawing.Point(366, 359)
        Me.lblOffset46.Name = "lblOffset46"
        Me.lblOffset46.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset46.TabIndex = 87
        Me.lblOffset46.Text = "                              "
        '
        'lblOffset54
        '
        Me.lblOffset54.AutoSize = True
        Me.lblOffset54.Location = New System.Drawing.Point(367, 411)
        Me.lblOffset54.Name = "lblOffset54"
        Me.lblOffset54.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset54.TabIndex = 111
        Me.lblOffset54.Text = "                              "
        '
        'lblOffset53
        '
        Me.lblOffset53.AutoSize = True
        Me.lblOffset53.Location = New System.Drawing.Point(219, 411)
        Me.lblOffset53.Name = "lblOffset53"
        Me.lblOffset53.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset53.TabIndex = 110
        Me.lblOffset53.Text = "                              "
        '
        'lblOffset52
        '
        Me.lblOffset52.AutoSize = True
        Me.lblOffset52.Location = New System.Drawing.Point(71, 411)
        Me.lblOffset52.Name = "lblOffset52"
        Me.lblOffset52.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset52.TabIndex = 108
        Me.lblOffset52.Text = "                              "
        '
        'lblOffset51
        '
        Me.lblOffset51.AutoSize = True
        Me.lblOffset51.Location = New System.Drawing.Point(512, 385)
        Me.lblOffset51.Name = "lblOffset51"
        Me.lblOffset51.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset51.TabIndex = 107
        Me.lblOffset51.Text = "                              "
        '
        'lblOffset45
        '
        Me.lblOffset45.AutoSize = True
        Me.lblOffset45.Location = New System.Drawing.Point(219, 359)
        Me.lblOffset45.Name = "lblOffset45"
        Me.lblOffset45.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset45.TabIndex = 92
        Me.lblOffset45.Text = "                              "
        '
        'lblOffset44
        '
        Me.lblOffset44.AutoSize = True
        Me.lblOffset44.Location = New System.Drawing.Point(71, 359)
        Me.lblOffset44.Name = "lblOffset44"
        Me.lblOffset44.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset44.TabIndex = 82
        Me.lblOffset44.Text = "                              "
        '
        'lblOffset43
        '
        Me.lblOffset43.AutoSize = True
        Me.lblOffset43.Location = New System.Drawing.Point(512, 333)
        Me.lblOffset43.Name = "lblOffset43"
        Me.lblOffset43.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset43.TabIndex = 79
        Me.lblOffset43.Text = "                              "
        '
        'lblOffset42
        '
        Me.lblOffset42.AutoSize = True
        Me.lblOffset42.Location = New System.Drawing.Point(365, 333)
        Me.lblOffset42.Name = "lblOffset42"
        Me.lblOffset42.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset42.TabIndex = 77
        Me.lblOffset42.Text = "                              "
        '
        'lblOffset40
        '
        Me.lblOffset40.AutoSize = True
        Me.lblOffset40.Location = New System.Drawing.Point(71, 333)
        Me.lblOffset40.Name = "lblOffset40"
        Me.lblOffset40.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset40.TabIndex = 95
        Me.lblOffset40.Text = "                              "
        '
        'lblOffset41
        '
        Me.lblOffset41.AutoSize = True
        Me.lblOffset41.Location = New System.Drawing.Point(218, 332)
        Me.lblOffset41.Name = "lblOffset41"
        Me.lblOffset41.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset41.TabIndex = 76
        Me.lblOffset41.Text = "                              "
        '
        'txtOffset30
        '
        Me.txtOffset30.Location = New System.Drawing.Point(307, 242)
        Me.txtOffset30.Name = "txtOffset30"
        Me.txtOffset30.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset30.TabIndex = 57
        Me.txtOffset30.Visible = False
        '
        'txtOffset20
        '
        Me.txtOffset20.Location = New System.Drawing.Point(12, 190)
        Me.txtOffset20.Name = "txtOffset20"
        Me.txtOffset20.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset20.TabIndex = 47
        Me.txtOffset20.Visible = False
        '
        'txtOffset29
        '
        Me.txtOffset29.Location = New System.Drawing.Point(160, 242)
        Me.txtOffset29.Name = "txtOffset29"
        Me.txtOffset29.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset29.TabIndex = 56
        Me.txtOffset29.Visible = False
        '
        'txtOffset31
        '
        Me.txtOffset31.Location = New System.Drawing.Point(453, 242)
        Me.txtOffset31.Name = "txtOffset31"
        Me.txtOffset31.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset31.TabIndex = 58
        Me.txtOffset31.Visible = False
        '
        'txtOffset27
        '
        Me.txtOffset27.Location = New System.Drawing.Point(453, 216)
        Me.txtOffset27.Name = "txtOffset27"
        Me.txtOffset27.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset27.TabIndex = 54
        Me.txtOffset27.Visible = False
        '
        'txtOffset32
        '
        Me.txtOffset32.Location = New System.Drawing.Point(12, 268)
        Me.txtOffset32.Name = "txtOffset32"
        Me.txtOffset32.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset32.TabIndex = 59
        Me.txtOffset32.Visible = False
        '
        'txtOffset28
        '
        Me.txtOffset28.Location = New System.Drawing.Point(12, 242)
        Me.txtOffset28.Name = "txtOffset28"
        Me.txtOffset28.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset28.TabIndex = 55
        Me.txtOffset28.Visible = False
        '
        'txtOffset23
        '
        Me.txtOffset23.Location = New System.Drawing.Point(453, 190)
        Me.txtOffset23.Name = "txtOffset23"
        Me.txtOffset23.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset23.TabIndex = 50
        Me.txtOffset23.Visible = False
        '
        'txtOffset33
        '
        Me.txtOffset33.Location = New System.Drawing.Point(160, 268)
        Me.txtOffset33.Name = "txtOffset33"
        Me.txtOffset33.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset33.TabIndex = 60
        Me.txtOffset33.Visible = False
        '
        'txtOffset22
        '
        Me.txtOffset22.Location = New System.Drawing.Point(306, 190)
        Me.txtOffset22.Name = "txtOffset22"
        Me.txtOffset22.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset22.TabIndex = 49
        Me.txtOffset22.Visible = False
        '
        'txtOffset34
        '
        Me.txtOffset34.Location = New System.Drawing.Point(306, 268)
        Me.txtOffset34.Name = "txtOffset34"
        Me.txtOffset34.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset34.TabIndex = 61
        Me.txtOffset34.Visible = False
        '
        'txtOffset21
        '
        Me.txtOffset21.Location = New System.Drawing.Point(159, 189)
        Me.txtOffset21.Name = "txtOffset21"
        Me.txtOffset21.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset21.TabIndex = 48
        Me.txtOffset21.Visible = False
        '
        'txtOffset35
        '
        Me.txtOffset35.Location = New System.Drawing.Point(453, 268)
        Me.txtOffset35.Name = "txtOffset35"
        Me.txtOffset35.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset35.TabIndex = 62
        Me.txtOffset35.Visible = False
        '
        'txtOffset26
        '
        Me.txtOffset26.Location = New System.Drawing.Point(306, 216)
        Me.txtOffset26.Name = "txtOffset26"
        Me.txtOffset26.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset26.TabIndex = 53
        Me.txtOffset26.Visible = False
        '
        'txtOffset36
        '
        Me.txtOffset36.Location = New System.Drawing.Point(12, 294)
        Me.txtOffset36.Name = "txtOffset36"
        Me.txtOffset36.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset36.TabIndex = 63
        Me.txtOffset36.Visible = False
        '
        'txtOffset25
        '
        Me.txtOffset25.Location = New System.Drawing.Point(159, 216)
        Me.txtOffset25.Name = "txtOffset25"
        Me.txtOffset25.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset25.TabIndex = 52
        Me.txtOffset25.Visible = False
        '
        'txtOffset37
        '
        Me.txtOffset37.Location = New System.Drawing.Point(158, 294)
        Me.txtOffset37.Name = "txtOffset37"
        Me.txtOffset37.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset37.TabIndex = 64
        Me.txtOffset37.Visible = False
        '
        'txtOffset38
        '
        Me.txtOffset38.Location = New System.Drawing.Point(305, 294)
        Me.txtOffset38.Name = "txtOffset38"
        Me.txtOffset38.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset38.TabIndex = 65
        Me.txtOffset38.Visible = False
        '
        'txtOffset24
        '
        Me.txtOffset24.Location = New System.Drawing.Point(12, 216)
        Me.txtOffset24.Name = "txtOffset24"
        Me.txtOffset24.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset24.TabIndex = 51
        Me.txtOffset24.Visible = False
        '
        'txtOffset39
        '
        Me.txtOffset39.Location = New System.Drawing.Point(452, 294)
        Me.txtOffset39.Name = "txtOffset39"
        Me.txtOffset39.Size = New System.Drawing.Size(141, 20)
        Me.txtOffset39.TabIndex = 66
        Me.txtOffset39.Visible = False
        '
        'lblOffset39
        '
        Me.lblOffset39.AutoSize = True
        Me.lblOffset39.Location = New System.Drawing.Point(511, 297)
        Me.lblOffset39.Name = "lblOffset39"
        Me.lblOffset39.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset39.TabIndex = 75
        Me.lblOffset39.Text = "                              "
        '
        'lblOffset38
        '
        Me.lblOffset38.AutoSize = True
        Me.lblOffset38.Location = New System.Drawing.Point(364, 297)
        Me.lblOffset38.Name = "lblOffset38"
        Me.lblOffset38.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset38.TabIndex = 74
        Me.lblOffset38.Text = "                              "
        '
        'lblOffset37
        '
        Me.lblOffset37.AutoSize = True
        Me.lblOffset37.Location = New System.Drawing.Point(217, 297)
        Me.lblOffset37.Name = "lblOffset37"
        Me.lblOffset37.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset37.TabIndex = 73
        Me.lblOffset37.Text = "                              "
        '
        'lblOffset36
        '
        Me.lblOffset36.AutoSize = True
        Me.lblOffset36.Location = New System.Drawing.Point(71, 297)
        Me.lblOffset36.Name = "lblOffset36"
        Me.lblOffset36.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset36.TabIndex = 69
        Me.lblOffset36.Text = "                              "
        '
        'lblOffset35
        '
        Me.lblOffset35.AutoSize = True
        Me.lblOffset35.Location = New System.Drawing.Point(514, 271)
        Me.lblOffset35.Name = "lblOffset35"
        Me.lblOffset35.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset35.TabIndex = 72
        Me.lblOffset35.Text = "                              "
        '
        'lblOffset28
        '
        Me.lblOffset28.AutoSize = True
        Me.lblOffset28.Location = New System.Drawing.Point(72, 245)
        Me.lblOffset28.Name = "lblOffset28"
        Me.lblOffset28.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset28.TabIndex = 49
        Me.lblOffset28.Text = "                              "
        '
        'lblOffset29
        '
        Me.lblOffset29.AutoSize = True
        Me.lblOffset29.Location = New System.Drawing.Point(218, 245)
        Me.lblOffset29.Name = "lblOffset29"
        Me.lblOffset29.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset29.TabIndex = 56
        Me.lblOffset29.Text = "                              "
        '
        'lblOffset30
        '
        Me.lblOffset30.AutoSize = True
        Me.lblOffset30.Location = New System.Drawing.Point(365, 245)
        Me.lblOffset30.Name = "lblOffset30"
        Me.lblOffset30.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset30.TabIndex = 57
        Me.lblOffset30.Text = "                              "
        '
        'lblOffset27
        '
        Me.lblOffset27.AutoSize = True
        Me.lblOffset27.Location = New System.Drawing.Point(513, 219)
        Me.lblOffset27.Name = "lblOffset27"
        Me.lblOffset27.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset27.TabIndex = 48
        Me.lblOffset27.Text = "                              "
        '
        'lblOffset26
        '
        Me.lblOffset26.AutoSize = True
        Me.lblOffset26.Location = New System.Drawing.Point(366, 219)
        Me.lblOffset26.Name = "lblOffset26"
        Me.lblOffset26.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset26.TabIndex = 47
        Me.lblOffset26.Text = "                              "
        '
        'lblOffset34
        '
        Me.lblOffset34.AutoSize = True
        Me.lblOffset34.Location = New System.Drawing.Point(368, 271)
        Me.lblOffset34.Name = "lblOffset34"
        Me.lblOffset34.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset34.TabIndex = 71
        Me.lblOffset34.Text = "                              "
        '
        'lblOffset33
        '
        Me.lblOffset33.AutoSize = True
        Me.lblOffset33.Location = New System.Drawing.Point(220, 271)
        Me.lblOffset33.Name = "lblOffset33"
        Me.lblOffset33.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset33.TabIndex = 70
        Me.lblOffset33.Text = "                              "
        '
        'lblOffset32
        '
        Me.lblOffset32.AutoSize = True
        Me.lblOffset32.Location = New System.Drawing.Point(72, 271)
        Me.lblOffset32.Name = "lblOffset32"
        Me.lblOffset32.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset32.TabIndex = 68
        Me.lblOffset32.Text = "                              "
        '
        'lblOffset31
        '
        Me.lblOffset31.AutoSize = True
        Me.lblOffset31.Location = New System.Drawing.Point(512, 245)
        Me.lblOffset31.Name = "lblOffset31"
        Me.lblOffset31.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset31.TabIndex = 67
        Me.lblOffset31.Text = "                              "
        '
        'lblOffset25
        '
        Me.lblOffset25.AutoSize = True
        Me.lblOffset25.Location = New System.Drawing.Point(219, 219)
        Me.lblOffset25.Name = "lblOffset25"
        Me.lblOffset25.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset25.TabIndex = 52
        Me.lblOffset25.Text = "                              "
        '
        'lblOffset24
        '
        Me.lblOffset24.AutoSize = True
        Me.lblOffset24.Location = New System.Drawing.Point(71, 219)
        Me.lblOffset24.Name = "lblOffset24"
        Me.lblOffset24.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset24.TabIndex = 42
        Me.lblOffset24.Text = "                              "
        '
        'lblOffset23
        '
        Me.lblOffset23.AutoSize = True
        Me.lblOffset23.Location = New System.Drawing.Point(512, 193)
        Me.lblOffset23.Name = "lblOffset23"
        Me.lblOffset23.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset23.TabIndex = 39
        Me.lblOffset23.Text = "                              "
        '
        'lblOffset22
        '
        Me.lblOffset22.AutoSize = True
        Me.lblOffset22.Location = New System.Drawing.Point(365, 193)
        Me.lblOffset22.Name = "lblOffset22"
        Me.lblOffset22.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset22.TabIndex = 37
        Me.lblOffset22.Text = "                              "
        '
        'lblOffset20
        '
        Me.lblOffset20.AutoSize = True
        Me.lblOffset20.Location = New System.Drawing.Point(71, 193)
        Me.lblOffset20.Name = "lblOffset20"
        Me.lblOffset20.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset20.TabIndex = 55
        Me.lblOffset20.Text = "                              "
        '
        'lblOffset21
        '
        Me.lblOffset21.AutoSize = True
        Me.lblOffset21.Location = New System.Drawing.Point(218, 192)
        Me.lblOffset21.Name = "lblOffset21"
        Me.lblOffset21.Size = New System.Drawing.Size(93, 13)
        Me.lblOffset21.TabIndex = 36
        Me.lblOffset21.Text = "                              "
        '
        'picInitialPicture
        '
        Me.picInitialPicture.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picInitialPicture.AutoSize = True
        Me.picInitialPicture.BackColor = System.Drawing.SystemColors.Control
        Me.picInitialPicture.Image = H_Name.My.Resources.Resources.loadAMap
        Me.picInitialPicture.Location = New System.Drawing.Point(123, 12)
        Me.picInitialPicture.Name = "picInitialPicture"
        Me.picInitialPicture.Size = New System.Drawing.Size(364, 32)
        Me.picInitialPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picInitialPicture.TabIndex = 18
        Me.picInitialPicture.TabStop = False
        Me.picInitialPicture.WaitOnLoad = True
        '
        'progLoading
        '
        Me.progLoading.Cursor = System.Windows.Forms.Cursors.WaitCursor
        Me.progLoading.Location = New System.Drawing.Point(0, 0)
        Me.progLoading.Maximum = 1000000
        Me.progLoading.Name = "progLoading"
        Me.progLoading.Size = New System.Drawing.Size(605, 24)
        Me.progLoading.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.progLoading.TabIndex = 116
        Me.progLoading.Visible = False
        '
        'formMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(605, 522)
        Me.Controls.Add(Me.statusMain)
        Me.Controls.Add(Me.menuMain)
        Me.Controls.Add(Me.vsbMain)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.progLoading)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(304, 208)
        Me.MainMenuStrip = Me.menuMain
        Me.Name = "formMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "H-Name"
        Me.statusMain.ResumeLayout(False)
        Me.menuMain.ResumeLayout(False)
        Me.pnlMain.ResumeLayout(False)
        Me.pnlMain.PerformLayout()
        CType(Me.picInitialPicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents statusMain As System.Windows.Forms.StatusStrip
    Friend WithEvents statusLblMapName As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents statusLblMapFilePath As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents openMap As System.Windows.Forms.OpenFileDialog
    Friend WithEvents menuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents statusLblSeparator As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents statusLblStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblOffset3 As System.Windows.Forms.Label
    Friend WithEvents txtOffset1 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset2 As System.Windows.Forms.Label
    Friend WithEvents txtOffset2 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset4 As System.Windows.Forms.Label
    Friend WithEvents txtOffset3 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset1 As System.Windows.Forms.Label
    Friend WithEvents txtOffset4 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset5 As System.Windows.Forms.Label
    Friend WithEvents txtOffset5 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset0 As System.Windows.Forms.Label
    Friend WithEvents txtOffset0 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset6 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset6 As System.Windows.Forms.Label
    Friend WithEvents lblOffset7 As System.Windows.Forms.Label
    Friend WithEvents txtOffset8 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset7 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset9 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset10 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset8 As System.Windows.Forms.Label
    Friend WithEvents lblOffset9 As System.Windows.Forms.Label
    Friend WithEvents lblOffset10 As System.Windows.Forms.Label
    Friend WithEvents txtOffset11 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset12 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset13 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset14 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset15 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset16 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset17 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset18 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset19 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset11 As System.Windows.Forms.Label
    Friend WithEvents lblOffset12 As System.Windows.Forms.Label
    Friend WithEvents lblOffset16 As System.Windows.Forms.Label
    Friend WithEvents lblOffset13 As System.Windows.Forms.Label
    Friend WithEvents lblOffset14 As System.Windows.Forms.Label
    Friend WithEvents lblOffset15 As System.Windows.Forms.Label
    Friend WithEvents lblOffset17 As System.Windows.Forms.Label
    Friend WithEvents lblOffset18 As System.Windows.Forms.Label
    Friend WithEvents lblOffset19 As System.Windows.Forms.Label
    Friend WithEvents vsbMain As System.Windows.Forms.VScrollBar
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents lblOffset39 As System.Windows.Forms.Label
    Friend WithEvents lblOffset38 As System.Windows.Forms.Label
    Friend WithEvents lblOffset37 As System.Windows.Forms.Label
    Friend WithEvents lblOffset36 As System.Windows.Forms.Label
    Friend WithEvents lblOffset35 As System.Windows.Forms.Label
    Friend WithEvents lblOffset28 As System.Windows.Forms.Label
    Friend WithEvents lblOffset29 As System.Windows.Forms.Label
    Friend WithEvents lblOffset30 As System.Windows.Forms.Label
    Friend WithEvents lblOffset27 As System.Windows.Forms.Label
    Friend WithEvents lblOffset26 As System.Windows.Forms.Label
    Friend WithEvents lblOffset34 As System.Windows.Forms.Label
    Friend WithEvents lblOffset33 As System.Windows.Forms.Label
    Friend WithEvents lblOffset32 As System.Windows.Forms.Label
    Friend WithEvents lblOffset31 As System.Windows.Forms.Label
    Friend WithEvents lblOffset25 As System.Windows.Forms.Label
    Friend WithEvents lblOffset24 As System.Windows.Forms.Label
    Friend WithEvents lblOffset23 As System.Windows.Forms.Label
    Friend WithEvents lblOffset22 As System.Windows.Forms.Label
    Friend WithEvents lblOffset20 As System.Windows.Forms.Label
    Friend WithEvents txtOffset30 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset20 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset29 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset31 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset27 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset21 As System.Windows.Forms.Label
    Friend WithEvents txtOffset32 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset28 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset23 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset33 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset22 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset34 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset21 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset35 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset26 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset36 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset25 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset37 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset38 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset24 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset39 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset50 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset40 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset49 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset51 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset47 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset52 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset48 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset43 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset53 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset42 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset54 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset41 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset55 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset46 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset56 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset45 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset57 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset58 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset44 As System.Windows.Forms.TextBox
    Friend WithEvents txtOffset59 As System.Windows.Forms.TextBox
    Friend WithEvents lblOffset59 As System.Windows.Forms.Label
    Friend WithEvents lblOffset58 As System.Windows.Forms.Label
    Friend WithEvents lblOffset57 As System.Windows.Forms.Label
    Friend WithEvents lblOffset56 As System.Windows.Forms.Label
    Friend WithEvents lblOffset55 As System.Windows.Forms.Label
    Friend WithEvents lblOffset48 As System.Windows.Forms.Label
    Friend WithEvents lblOffset49 As System.Windows.Forms.Label
    Friend WithEvents lblOffset50 As System.Windows.Forms.Label
    Friend WithEvents lblOffset47 As System.Windows.Forms.Label
    Friend WithEvents lblOffset46 As System.Windows.Forms.Label
    Friend WithEvents lblOffset54 As System.Windows.Forms.Label
    Friend WithEvents lblOffset53 As System.Windows.Forms.Label
    Friend WithEvents lblOffset52 As System.Windows.Forms.Label
    Friend WithEvents lblOffset51 As System.Windows.Forms.Label
    Friend WithEvents lblOffset45 As System.Windows.Forms.Label
    Friend WithEvents lblOffset44 As System.Windows.Forms.Label
    Friend WithEvents lblOffset43 As System.Windows.Forms.Label
    Friend WithEvents lblOffset42 As System.Windows.Forms.Label
    Friend WithEvents lblOffset40 As System.Windows.Forms.Label
    Friend WithEvents lblOffset41 As System.Windows.Forms.Label
    Friend WithEvents progLoading As System.Windows.Forms.ProgressBar
    Friend WithEvents menuBtnOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnClose As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnManagePlugins As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnPluginConverter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnViewPlugin As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnHelpAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuBtnDebug As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents picInitialPicture As System.Windows.Forms.PictureBox

End Class
