<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class formPlugins
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formPlugins))
        Me.writeBackwash = New System.Windows.Forms.CheckBox
        Me.writeContainment = New System.Windows.Forms.CheckBox
        Me.writeDeltatap = New System.Windows.Forms.CheckBox
        Me.writeDune = New System.Windows.Forms.CheckBox
        Me.writeElongation = New System.Windows.Forms.CheckBox
        Me.writeGemini = New System.Windows.Forms.CheckBox
        Me.writeTriplicate = New System.Windows.Forms.CheckBox
        Me.writeTurf = New System.Windows.Forms.CheckBox
        Me.writeWarlock = New System.Windows.Forms.CheckBox
        Me.writeAscension = New System.Windows.Forms.CheckBox
        Me.writeBeaverCreek = New System.Windows.Forms.CheckBox
        Me.writeBurial_Mounds = New System.Windows.Forms.CheckBox
        Me.writeCoagulation = New System.Windows.Forms.CheckBox
        Me.writeColossus = New System.Windows.Forms.CheckBox
        Me.writeCyclotron = New System.Windows.Forms.CheckBox
        Me.btnWritePlugins = New System.Windows.Forms.Button
        Me.btnDeletePlugins = New System.Windows.Forms.Button
        Me.writeFoundation = New System.Windows.Forms.CheckBox
        Me.writeHeadlong = New System.Windows.Forms.CheckBox
        Me.writeLockout = New System.Windows.Forms.CheckBox
        Me.writeMidship = New System.Windows.Forms.CheckBox
        Me.writeWaterworks = New System.Windows.Forms.CheckBox
        Me.writeZanzibar = New System.Windows.Forms.CheckBox
        Me.writeShared = New System.Windows.Forms.CheckBox
        Me.writeMainmenu = New System.Windows.Forms.CheckBox
        Me.writeBlank = New System.Windows.Forms.CheckBox
        Me.grpNewMaps = New System.Windows.Forms.GroupBox
        Me.grpOldMaps = New System.Windows.Forms.GroupBox
        Me.grpOther = New System.Windows.Forms.GroupBox
        Me.btnCheckAll = New System.Windows.Forms.Button
        Me.btnUncheckAll = New System.Windows.Forms.Button
        Me.listDetectedPlugins = New System.Windows.Forms.ListBox
        Me.grpNewMaps.SuspendLayout()
        Me.grpOldMaps.SuspendLayout()
        Me.grpOther.SuspendLayout()
        Me.SuspendLayout()
        '
        'writeBackwash
        '
        Me.writeBackwash.AutoSize = True
        Me.writeBackwash.Location = New System.Drawing.Point(6, 19)
        Me.writeBackwash.Name = "writeBackwash"
        Me.writeBackwash.Size = New System.Drawing.Size(72, 17)
        Me.writeBackwash.TabIndex = 0
        Me.writeBackwash.Text = "Backwash"
        '
        'writeContainment
        '
        Me.writeContainment.AutoSize = True
        Me.writeContainment.Location = New System.Drawing.Point(6, 42)
        Me.writeContainment.Name = "writeContainment"
        Me.writeContainment.Size = New System.Drawing.Size(81, 17)
        Me.writeContainment.TabIndex = 1
        Me.writeContainment.Text = "Containment"
        '
        'writeDeltatap
        '
        Me.writeDeltatap.AutoSize = True
        Me.writeDeltatap.Location = New System.Drawing.Point(6, 65)
        Me.writeDeltatap.Name = "writeDeltatap"
        Me.writeDeltatap.Size = New System.Drawing.Size(62, 17)
        Me.writeDeltatap.TabIndex = 2
        Me.writeDeltatap.Text = "Deltatap"
        '
        'writeDune
        '
        Me.writeDune.AutoSize = True
        Me.writeDune.Location = New System.Drawing.Point(6, 88)
        Me.writeDune.Name = "writeDune"
        Me.writeDune.Size = New System.Drawing.Size(48, 17)
        Me.writeDune.TabIndex = 3
        Me.writeDune.Text = "Dune"
        '
        'writeElongation
        '
        Me.writeElongation.AutoSize = True
        Me.writeElongation.Location = New System.Drawing.Point(6, 111)
        Me.writeElongation.Name = "writeElongation"
        Me.writeElongation.Size = New System.Drawing.Size(72, 17)
        Me.writeElongation.TabIndex = 4
        Me.writeElongation.Text = "Elongation"
        '
        'writeGemini
        '
        Me.writeGemini.AutoSize = True
        Me.writeGemini.Location = New System.Drawing.Point(6, 134)
        Me.writeGemini.Name = "writeGemini"
        Me.writeGemini.Size = New System.Drawing.Size(54, 17)
        Me.writeGemini.TabIndex = 5
        Me.writeGemini.Text = "Gemini"
        '
        'writeTriplicate
        '
        Me.writeTriplicate.AutoSize = True
        Me.writeTriplicate.Location = New System.Drawing.Point(6, 157)
        Me.writeTriplicate.Name = "writeTriplicate"
        Me.writeTriplicate.Size = New System.Drawing.Size(65, 17)
        Me.writeTriplicate.TabIndex = 6
        Me.writeTriplicate.Text = "Triplicate"
        '
        'writeTurf
        '
        Me.writeTurf.AutoSize = True
        Me.writeTurf.Location = New System.Drawing.Point(6, 180)
        Me.writeTurf.Name = "writeTurf"
        Me.writeTurf.Size = New System.Drawing.Size(41, 17)
        Me.writeTurf.TabIndex = 7
        Me.writeTurf.Text = "Turf"
        '
        'writeWarlock
        '
        Me.writeWarlock.AutoSize = True
        Me.writeWarlock.Location = New System.Drawing.Point(6, 203)
        Me.writeWarlock.Name = "writeWarlock"
        Me.writeWarlock.Size = New System.Drawing.Size(62, 17)
        Me.writeWarlock.TabIndex = 8
        Me.writeWarlock.Text = "Warlock"
        '
        'writeAscension
        '
        Me.writeAscension.AutoSize = True
        Me.writeAscension.Location = New System.Drawing.Point(6, 19)
        Me.writeAscension.Name = "writeAscension"
        Me.writeAscension.Size = New System.Drawing.Size(71, 17)
        Me.writeAscension.TabIndex = 9
        Me.writeAscension.Text = "Ascension"
        '
        'writeBeaverCreek
        '
        Me.writeBeaverCreek.AutoSize = True
        Me.writeBeaverCreek.Location = New System.Drawing.Point(6, 42)
        Me.writeBeaverCreek.Name = "writeBeaverCreek"
        Me.writeBeaverCreek.Size = New System.Drawing.Size(87, 17)
        Me.writeBeaverCreek.TabIndex = 10
        Me.writeBeaverCreek.Text = "Beaver Creek"
        '
        'writeBurial_Mounds
        '
        Me.writeBurial_Mounds.AutoSize = True
        Me.writeBurial_Mounds.Location = New System.Drawing.Point(6, 65)
        Me.writeBurial_Mounds.Name = "writeBurial_Mounds"
        Me.writeBurial_Mounds.Size = New System.Drawing.Size(89, 17)
        Me.writeBurial_Mounds.TabIndex = 11
        Me.writeBurial_Mounds.Text = "Burial Mounds"
        '
        'writeCoagulation
        '
        Me.writeCoagulation.AutoSize = True
        Me.writeCoagulation.Location = New System.Drawing.Point(6, 88)
        Me.writeCoagulation.Name = "writeCoagulation"
        Me.writeCoagulation.Size = New System.Drawing.Size(78, 17)
        Me.writeCoagulation.TabIndex = 12
        Me.writeCoagulation.Text = "Coagulation"
        '
        'writeColossus
        '
        Me.writeColossus.AutoSize = True
        Me.writeColossus.Location = New System.Drawing.Point(6, 111)
        Me.writeColossus.Name = "writeColossus"
        Me.writeColossus.Size = New System.Drawing.Size(64, 17)
        Me.writeColossus.TabIndex = 13
        Me.writeColossus.Text = "Colossus"
        '
        'writeCyclotron
        '
        Me.writeCyclotron.AutoSize = True
        Me.writeCyclotron.Location = New System.Drawing.Point(6, 134)
        Me.writeCyclotron.Name = "writeCyclotron"
        Me.writeCyclotron.Size = New System.Drawing.Size(66, 17)
        Me.writeCyclotron.TabIndex = 14
        Me.writeCyclotron.Text = "Cyclotron"
        '
        'btnWritePlugins
        '
        Me.btnWritePlugins.AutoSize = True
        Me.btnWritePlugins.Location = New System.Drawing.Point(212, 12)
        Me.btnWritePlugins.Name = "btnWritePlugins"
        Me.btnWritePlugins.Size = New System.Drawing.Size(81, 23)
        Me.btnWritePlugins.TabIndex = 15
        Me.btnWritePlugins.Text = "Write Plugins"
        '
        'btnDeletePlugins
        '
        Me.btnDeletePlugins.AutoSize = True
        Me.btnDeletePlugins.Location = New System.Drawing.Point(212, 41)
        Me.btnDeletePlugins.Name = "btnDeletePlugins"
        Me.btnDeletePlugins.Size = New System.Drawing.Size(81, 23)
        Me.btnDeletePlugins.TabIndex = 16
        Me.btnDeletePlugins.Text = "Delete Plugins"
        '
        'writeFoundation
        '
        Me.writeFoundation.AutoSize = True
        Me.writeFoundation.Location = New System.Drawing.Point(6, 157)
        Me.writeFoundation.Name = "writeFoundation"
        Me.writeFoundation.Size = New System.Drawing.Size(75, 17)
        Me.writeFoundation.TabIndex = 17
        Me.writeFoundation.Text = "Foundation"
        '
        'writeHeadlong
        '
        Me.writeHeadlong.AutoSize = True
        Me.writeHeadlong.Location = New System.Drawing.Point(6, 180)
        Me.writeHeadlong.Name = "writeHeadlong"
        Me.writeHeadlong.Size = New System.Drawing.Size(68, 17)
        Me.writeHeadlong.TabIndex = 18
        Me.writeHeadlong.Text = "Headlong"
        '
        'writeLockout
        '
        Me.writeLockout.AutoSize = True
        Me.writeLockout.Location = New System.Drawing.Point(6, 203)
        Me.writeLockout.Name = "writeLockout"
        Me.writeLockout.Size = New System.Drawing.Size(61, 17)
        Me.writeLockout.TabIndex = 19
        Me.writeLockout.Text = "Lockout"
        '
        'writeMidship
        '
        Me.writeMidship.AutoSize = True
        Me.writeMidship.Location = New System.Drawing.Point(6, 226)
        Me.writeMidship.Name = "writeMidship"
        Me.writeMidship.Size = New System.Drawing.Size(58, 17)
        Me.writeMidship.TabIndex = 20
        Me.writeMidship.Text = "Midship"
        '
        'writeWaterworks
        '
        Me.writeWaterworks.AutoSize = True
        Me.writeWaterworks.Location = New System.Drawing.Point(6, 249)
        Me.writeWaterworks.Name = "writeWaterworks"
        Me.writeWaterworks.Size = New System.Drawing.Size(79, 17)
        Me.writeWaterworks.TabIndex = 21
        Me.writeWaterworks.Text = "Waterworks"
        '
        'writeZanzibar
        '
        Me.writeZanzibar.AutoSize = True
        Me.writeZanzibar.Location = New System.Drawing.Point(6, 272)
        Me.writeZanzibar.Name = "writeZanzibar"
        Me.writeZanzibar.Size = New System.Drawing.Size(63, 17)
        Me.writeZanzibar.TabIndex = 22
        Me.writeZanzibar.Text = "Zanzibar"
        '
        'writeShared
        '
        Me.writeShared.AutoSize = True
        Me.writeShared.Location = New System.Drawing.Point(6, 19)
        Me.writeShared.Name = "writeShared"
        Me.writeShared.Size = New System.Drawing.Size(56, 17)
        Me.writeShared.TabIndex = 23
        Me.writeShared.Text = "Shared"
        '
        'writeMainmenu
        '
        Me.writeMainmenu.AutoSize = True
        Me.writeMainmenu.Location = New System.Drawing.Point(6, 42)
        Me.writeMainmenu.Name = "writeMainmenu"
        Me.writeMainmenu.Size = New System.Drawing.Size(71, 17)
        Me.writeMainmenu.TabIndex = 24
        Me.writeMainmenu.Text = "Mainmenu"
        '
        'writeBlank
        '
        Me.writeBlank.AutoSize = True
        Me.writeBlank.Location = New System.Drawing.Point(6, 65)
        Me.writeBlank.Name = "writeBlank"
        Me.writeBlank.Size = New System.Drawing.Size(49, 17)
        Me.writeBlank.TabIndex = 25
        Me.writeBlank.Text = "Blank"
        '
        'grpNewMaps
        '
        Me.grpNewMaps.AutoSize = True
        Me.grpNewMaps.Controls.Add(Me.writeBackwash)
        Me.grpNewMaps.Controls.Add(Me.writeContainment)
        Me.grpNewMaps.Controls.Add(Me.writeDeltatap)
        Me.grpNewMaps.Controls.Add(Me.writeDune)
        Me.grpNewMaps.Controls.Add(Me.writeElongation)
        Me.grpNewMaps.Controls.Add(Me.writeWarlock)
        Me.grpNewMaps.Controls.Add(Me.writeGemini)
        Me.grpNewMaps.Controls.Add(Me.writeTurf)
        Me.grpNewMaps.Controls.Add(Me.writeTriplicate)
        Me.grpNewMaps.Location = New System.Drawing.Point(116, 12)
        Me.grpNewMaps.Name = "grpNewMaps"
        Me.grpNewMaps.Size = New System.Drawing.Size(90, 223)
        Me.grpNewMaps.TabIndex = 26
        Me.grpNewMaps.TabStop = False
        Me.grpNewMaps.Text = "New Maps"
        '
        'grpOldMaps
        '
        Me.grpOldMaps.AutoSize = True
        Me.grpOldMaps.Controls.Add(Me.writeAscension)
        Me.grpOldMaps.Controls.Add(Me.writeBeaverCreek)
        Me.grpOldMaps.Controls.Add(Me.writeBurial_Mounds)
        Me.grpOldMaps.Controls.Add(Me.writeCoagulation)
        Me.grpOldMaps.Controls.Add(Me.writeColossus)
        Me.grpOldMaps.Controls.Add(Me.writeCyclotron)
        Me.grpOldMaps.Controls.Add(Me.writeZanzibar)
        Me.grpOldMaps.Controls.Add(Me.writeFoundation)
        Me.grpOldMaps.Controls.Add(Me.writeWaterworks)
        Me.grpOldMaps.Controls.Add(Me.writeHeadlong)
        Me.grpOldMaps.Controls.Add(Me.writeMidship)
        Me.grpOldMaps.Controls.Add(Me.writeLockout)
        Me.grpOldMaps.Location = New System.Drawing.Point(12, 12)
        Me.grpOldMaps.Name = "grpOldMaps"
        Me.grpOldMaps.Size = New System.Drawing.Size(98, 314)
        Me.grpOldMaps.TabIndex = 27
        Me.grpOldMaps.TabStop = False
        Me.grpOldMaps.Text = "Old Maps"
        '
        'grpOther
        '
        Me.grpOther.AutoSize = True
        Me.grpOther.Controls.Add(Me.writeShared)
        Me.grpOther.Controls.Add(Me.writeMainmenu)
        Me.grpOther.Controls.Add(Me.writeBlank)
        Me.grpOther.Location = New System.Drawing.Point(116, 241)
        Me.grpOther.Name = "grpOther"
        Me.grpOther.Size = New System.Drawing.Size(90, 85)
        Me.grpOther.TabIndex = 28
        Me.grpOther.TabStop = False
        Me.grpOther.Text = "Other"
        '
        'btnCheckAll
        '
        Me.btnCheckAll.AutoSize = True
        Me.btnCheckAll.Location = New System.Drawing.Point(212, 70)
        Me.btnCheckAll.Name = "btnCheckAll"
        Me.btnCheckAll.Size = New System.Drawing.Size(81, 23)
        Me.btnCheckAll.TabIndex = 29
        Me.btnCheckAll.Text = "Check All"
        '
        'btnUncheckAll
        '
        Me.btnUncheckAll.Location = New System.Drawing.Point(212, 99)
        Me.btnUncheckAll.Name = "btnUncheckAll"
        Me.btnUncheckAll.Size = New System.Drawing.Size(81, 23)
        Me.btnUncheckAll.TabIndex = 30
        Me.btnUncheckAll.Text = "Uncheck All"
        '
        'listDetectedPlugins
        '
        Me.listDetectedPlugins.FormattingEnabled = True
        Me.listDetectedPlugins.Items.AddRange(New Object() {"--==Plugins==--", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "--==Plugins==--"})
        Me.listDetectedPlugins.Location = New System.Drawing.Point(212, 128)
        Me.listDetectedPlugins.Name = "listDetectedPlugins"
        Me.listDetectedPlugins.Size = New System.Drawing.Size(98, 199)
        Me.listDetectedPlugins.TabIndex = 31
        '
        'formPlugins
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(319, 335)
        Me.Controls.Add(Me.listDetectedPlugins)
        Me.Controls.Add(Me.btnUncheckAll)
        Me.Controls.Add(Me.btnCheckAll)
        Me.Controls.Add(Me.grpOther)
        Me.Controls.Add(Me.grpOldMaps)
        Me.Controls.Add(Me.grpNewMaps)
        Me.Controls.Add(Me.btnDeletePlugins)
        Me.Controls.Add(Me.btnWritePlugins)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "formPlugins"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Plugin Options"
        Me.grpNewMaps.ResumeLayout(False)
        Me.grpNewMaps.PerformLayout()
        Me.grpOldMaps.ResumeLayout(False)
        Me.grpOldMaps.PerformLayout()
        Me.grpOther.ResumeLayout(False)
        Me.grpOther.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents writeBackwash As System.Windows.Forms.CheckBox
    Friend WithEvents writeContainment As System.Windows.Forms.CheckBox
    Friend WithEvents writeDeltatap As System.Windows.Forms.CheckBox
    Friend WithEvents writeDune As System.Windows.Forms.CheckBox
    Friend WithEvents writeElongation As System.Windows.Forms.CheckBox
    Friend WithEvents writeGemini As System.Windows.Forms.CheckBox
    Friend WithEvents writeTriplicate As System.Windows.Forms.CheckBox
    Friend WithEvents writeTurf As System.Windows.Forms.CheckBox
    Friend WithEvents writeWarlock As System.Windows.Forms.CheckBox
    Friend WithEvents writeAscension As System.Windows.Forms.CheckBox
    Friend WithEvents writeBeaverCreek As System.Windows.Forms.CheckBox
    Friend WithEvents writeBurial_Mounds As System.Windows.Forms.CheckBox
    Friend WithEvents writeCoagulation As System.Windows.Forms.CheckBox
    Friend WithEvents writeColossus As System.Windows.Forms.CheckBox
    Friend WithEvents writeCyclotron As System.Windows.Forms.CheckBox
    Friend WithEvents btnWritePlugins As System.Windows.Forms.Button
    Friend WithEvents btnDeletePlugins As System.Windows.Forms.Button
    Friend WithEvents writeFoundation As System.Windows.Forms.CheckBox
    Friend WithEvents writeHeadlong As System.Windows.Forms.CheckBox
    Friend WithEvents writeLockout As System.Windows.Forms.CheckBox
    Friend WithEvents writeMidship As System.Windows.Forms.CheckBox
    Friend WithEvents writeWaterworks As System.Windows.Forms.CheckBox
    Friend WithEvents writeZanzibar As System.Windows.Forms.CheckBox
    Friend WithEvents writeShared As System.Windows.Forms.CheckBox
    Friend WithEvents writeMainmenu As System.Windows.Forms.CheckBox
    Friend WithEvents writeBlank As System.Windows.Forms.CheckBox
    Friend WithEvents grpNewMaps As System.Windows.Forms.GroupBox
    Friend WithEvents grpOldMaps As System.Windows.Forms.GroupBox
    Friend WithEvents grpOther As System.Windows.Forms.GroupBox
    Friend WithEvents btnCheckAll As System.Windows.Forms.Button
    Friend WithEvents btnUncheckAll As System.Windows.Forms.Button
    Friend WithEvents listDetectedPlugins As System.Windows.Forms.ListBox
End Class
