﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Patch Master")> 
<Assembly: AssemblyDescription("Applies and creates multiple patches and more...")> 
<Assembly: AssemblyCompany("13 Willows")> 
<Assembly: AssemblyProduct("Patch Master")> 
<Assembly: AssemblyCopyright("©2006")> 
<Assembly: AssemblyTrademark("Two roads diverged in the woods, and I, I took the one less traveled upon.")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("219ba530-0807-42c7-802f-87f1dda6e53f")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
